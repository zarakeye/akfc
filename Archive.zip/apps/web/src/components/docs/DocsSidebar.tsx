
import Link from "next/link"
import { getAllDocs } from "@/lib/docs/docs.source"

export function DocsSidebar() {
  const pages = getAllDocs()

  return (
    <aside className="w-64 border-r p-6">
      <h3 className="text-xs uppercase mb-4">Documentation</h3>

      <ul className="space-y-2 text-sm">
        {pages.map((page) => (
          <li key={page.slug.join("/")}>
            <Link href={`/docs/${page.slug.join("/")}`}>
              {page.title}
            </Link>
          </li>
        ))}
      </ul>
    </aside>
  )
}
