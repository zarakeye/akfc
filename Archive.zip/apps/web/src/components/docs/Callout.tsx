
export function Callout({
  title = "Note",
  children,
}: {
  title?: string
  children: React.ReactNode
}) {
  return (
    <div className="border rounded-xl p-4 my-6 bg-muted">
      <strong className="block mb-2">{title}</strong>
      <div>{children}</div>
    </div>
  )
}
