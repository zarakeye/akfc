
import { ReactNode } from "react"
import { DocsSidebar } from "./DocsSidebar"

export function DocsLayout({
  title,
  children,
}: {
  title: string
  children: ReactNode
}) {
  return (
    <div className="flex max-w-7xl mx-auto">
      <DocsSidebar />
      <main className="flex-1 p-10">
        <h1 className="text-4xl font-bold mb-8">{title}</h1>
        {children}
      </main>
    </div>
  )
}
