
import Link from "next/link"
import type { DocPage } from "@/lib/docs/docs.types"

export function DocsPagination({
  prev,
  next,
}: {
  prev: DocPage | null
  next: DocPage | null
}) {
  return (
    <div className="flex justify-between border-t pt-6 mt-10 text-sm">
      {prev ? (
        <Link href={`/docs/${prev.slug.join("/")}`}>
          ← {prev.title}
        </Link>
      ) : (
        <div />
      )}

      {next ? (
        <Link href={`/docs/${next.slug.join("/")}`}>
          {next.title} →
        </Link>
      ) : null}
    </div>
  )
}
