
import Link from "next/link"

export function Breadcrumbs({ slug }: { slug: string[] }) {
  return (
    <nav className="text-xs mb-6">
      <Link href="/docs">Docs</Link>

      {slug.map((s, i) => (
        <span key={i}>
          {" / "}
          <Link href={"/docs/" + slug.slice(0, i + 1).join("/")}>
            {s}
          </Link>
        </span>
      ))}
    </nav>
  )
}
