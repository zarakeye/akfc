
"use client"
import { useState } from "react"

export function CodeBlock({ code }: { code: string }) {
  const [copied, setCopied] = useState(false)

  async function copy() {
    await navigator.clipboard.writeText(code)
    setCopied(true)
    setTimeout(() => setCopied(false), 1200)
  }

  return (
    <div className="my-6 border rounded-lg">
      <div className="flex justify-end p-2 text-xs">
        <button onClick={copy}>
          {copied ? "Copied" : "Copy"}
        </button>
      </div>

      <pre className="p-4 overflow-x-auto">
        <code>{code}</code>
      </pre>
    </div>
  )
}
