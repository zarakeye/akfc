
import fs from "node:fs"
import path from "node:path"
import matter from "gray-matter"

import { DocsLayout } from "@/components/docs/DocsLayout"
import { DocsToc } from "@/components/docs/DocsToc"
import { DocsPagination } from "@/components/docs/DocsPagination"
import { Breadcrumbs } from "@/components/docs/Breadcrumbs"

import { extractToc } from "@/lib/docs/docs.toc"
import { getAllDocs } from "@/lib/docs/docs.source"
import { getPrevNext } from "@/lib/docs/docs.navigation"

export default async function DocPage({
  params,
}: {
  params: { slug: string[] }
}) {
  const slug = params.slug ?? []

  const filePath =
    path.join(process.cwd(), "apps/web/content/docs", ...slug) + ".mdx"

  const source = fs.readFileSync(filePath, "utf8")

  const { content, data } = matter(source)

  const toc = extractToc(content)

  const pages = getAllDocs()

  const { prev, next } = getPrevNext(pages, slug)

  const Content = (
    await import(`@/content/docs/${slug.join("/")}.mdx`)
  ).default

  return (
    <DocsLayout title={data.title}>
      <Breadcrumbs slug={slug} />

      <div className="flex">
        <article className="flex-1">
          <Content />
          <DocsPagination prev={prev} next={next} />
        </article>

        <DocsToc items={toc} />
      </div>
    </DocsLayout>
  )
}
