import { JSX } from "react"
import { SimpleEditor } from "apps/web/src/features/editor-tiptap/templates/simple/simple-editor"

export default function Page(): JSX.Element {
  return <SimpleEditor />
}
