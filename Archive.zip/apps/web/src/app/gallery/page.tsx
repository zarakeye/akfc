import { JSX } from 'react';
import PicturesDragNDropForm from 'apps/web/src/features/admin-forms/components/PicturesDragNDropForm';

export default function Gallery(): JSX.Element {
  return (
    <main>
      <h1>Gallery</h1>
      <PicturesDragNDropForm />
    </main>
  );
}