'use client';

import React, { JSX, useState, useEffect } from 'react';
import { trpc } from 'apps/web/src/lib/trpcClient';
import { Table, type Column } from 'react-ts-tab-lib';
import Image from 'next/image';
import type { User, Role } from '@prisma/client';
import UpdateUserRoleById from './UpdateUserRoleById';

/**
 * UsersList component
 * 
 * This component is responsible for displaying a list of all users from the database.
 * It uses the trpc.user.getAll hook to fetch the data and the react-ts-tab-lib library to render the table.
 * 
 * The component also handles loading and error states for both the users and roles data.
 * 
 * @returns {JSX.Element} A JSX element representing the UsersList component.
 */
export default function UsersList(): JSX.Element {
  const usersQuery = trpc.user.getAll.useQuery();
  const { data: users = [], isLoading, isError } = usersQuery;
  const [isUsersLoading, setIsUsersLoading] = useState(false);
  const [isUsersLoadingError, setIsUsersLoadingError] = useState(false);

  useEffect(() => {
    setIsUsersLoading(isLoading);
  }, [isLoading]);
  useEffect(() => {
    setIsUsersLoadingError(isError);
  }, [isError]);

  const { data: roles = [] as Role[]} = trpc.role.getAll.useQuery();
  const [isRolesLoading, setIsRolesLoading] = useState(false);
  const [isRolesLoadingError, setIsRolesLoadingError] = useState(false);

  useEffect(() => {
    setIsRolesLoading(roles.length === 0);
  }, [roles]);
  useEffect(() => {
    setIsRolesLoadingError(isError);
  }, [isError]);

  const columns: Column<User>[] = [
    { property: 'firstName', displayName: 'Prénom', type: 'string' },
    { property: 'lastName', displayName: 'Nom', type: 'string' },
    { property: 'email', displayName: 'Email', type: 'string' },
    {
      property: 'roleId',
      displayName: 'Rôle',
      type: 'string',
      // NOTE: la lib ne type pas toujours `row` dans la signature -> cast minimal.
      render: ((roleId: unknown, row: unknown) => {
        const u = row as User;
        return (
          <UpdateUserRoleById
            userId={u.id}
            currentRoleId={(roleId as number | null) ?? null}
            roles={roles}
            onChanged={() => usersQuery.refetch()}
          />
        );
      }) as Column<User>['render'],
    },
    { property: 'createdAt', displayName: 'Date de création', type: 'string', render: (v) => formatDate(v) },
    { property: 'updatedAt', displayName: 'Date de mise à jour', type: 'string', render: (v) => formatDate(v) },
    { property: 'pseudo', displayName: 'Pseudo', type: 'string' },
    { property: 'phone', displayName: 'Numéro de téléphone', type: 'string' },
    { property: 'birthDate', displayName: 'Date de naissance', type: 'string', render: (v) => formatDate(v) },
    { property: 'memberSince', displayName: 'Membre depuis', type: 'string', render: (v) => formatDate(v) },
    { property: 'aboutMe', displayName: 'À propos de moi', type: 'string' },
    { property: 'avatar', displayName: 'Avatar', type: 'string', render: (avatar) => (typeof avatar === 'string' && avatar)
      ? <Image src={avatar} alt="avatar" width={50} height={50} className="rounded-full" />
      : <span className="text-slate-500">No Avatar</span> },
  ];

  const formatDate = (value: string | number | boolean | Date | null): React.ReactNode => {
    if (!value) return <span className="text-slate-500">Non renseigné</span>;
    if (typeof value === 'boolean') return <span className="text-slate-500">-</span>;
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return <span className="text-slate-500">-</span>;
    return <span>{d.toLocaleDateString()}</span>;
  };

  // Remove nested role relation for Table<User>
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const sanitizedUsers = users.map(({ role, ...rest }) => rest);
  console.log('Sanitized Users:', sanitizedUsers);

  return (
    isUsersLoading || isRolesLoading 
    ? <div>Loading...</div>
    : isUsersLoadingError
      ? <div>Error loading users.</div>
      : isRolesLoadingError 
        ? <div>Error loading roles.</div>
        : (
          <div className="w-full">
            <Table columns={columns} rows={sanitizedUsers} />
          </div>
        )
  );
}
