
import fs from "node:fs"
import path from "node:path"
import matter from "gray-matter"
import type { DocPage } from "./docs.types"

const DOCS_PATH = path.join(process.cwd(), "apps/web/content/docs")

export function getAllDocs(): DocPage[] {
  const pages: DocPage[] = []

  function walk(dir: string, slug: string[] = []) {
    const entries = fs.readdirSync(dir)

    for (const entry of entries) {
      const full = path.join(dir, entry)
      const stat = fs.statSync(full)

      if (stat.isDirectory()) {
        walk(full, [...slug, entry])
      } else if (entry.endsWith(".mdx")) {
        const file = fs.readFileSync(full, "utf8")
        const { data } = matter(file)

        pages.push({
          slug: [...slug, entry.replace(".mdx", "")],
          title: data.title ?? entry,
          section: data.section,
          order: data.order,
        })
      }
    }
  }

  walk(DOCS_PATH)

  return pages.sort((a, b) => (a.order ?? 999) - (b.order ?? 999))
}
