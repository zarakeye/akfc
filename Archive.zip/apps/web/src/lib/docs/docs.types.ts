
export interface DocFrontmatter {
  title: string
  description?: string
  section?: string
  order?: number
}

export interface DocPage {
  slug: string[]
  title: string
  section?: string
  order?: number
}
