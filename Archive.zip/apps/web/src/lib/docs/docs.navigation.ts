
import type { DocPage } from "./docs.types"

export function getPrevNext(pages: DocPage[], slug: string[]) {
  const index = pages.findIndex(
    (p) => p.slug.join("/") === slug.join("/")
  )

  return {
    prev: index > 0 ? pages[index - 1] : null,
    next: index < pages.length - 1 ? pages[index + 1] : null,
  }
}
