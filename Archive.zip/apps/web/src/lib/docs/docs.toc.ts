
import { unified } from "unified"
import remarkParse from "remark-parse"
import { visit } from "unist-util-visit"

export interface TocItem {
  depth: number
  value: string
  id: string
}

export function extractToc(markdown: string): TocItem[] {
  const tree = unified().use(remarkParse).parse(markdown)

  const toc: TocItem[] = []

  visit(tree, "heading", (node: any) => {
    const text = node.children
      .map((c: any) => c.value || "")
      .join("")

    const id = text
      .toLowerCase()
      .replace(/[^a-z0-9 ]/g, "")
      .replace(/\s+/g, "-")

    toc.push({
      depth: node.depth,
      value: text,
      id,
    })
  })

  return toc
}
