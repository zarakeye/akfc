(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/ec2e8_next_dist_compiled_bde4f1e9._.js",
  "static/chunks/ec2e8_next_dist_shared_lib_2d3cd3ba._.js",
  "static/chunks/ec2e8_next_dist_client_4b781ec3._.js",
  "static/chunks/ec2e8_next_dist_fe3ea685._.js",
  "static/chunks/ec2e8_next_app_935fc49f.js",
  "static/chunks/[next]_entry_page-loader_ts_237e66a1._.js",
  "static/chunks/76102_react-dom_44795136._.js",
  "static/chunks/node_modules__pnpm_7136f466._.js",
  "static/chunks/[root-of-the-server]__67058656._.js"
],
    source: "entry"
});
