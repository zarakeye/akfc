module.exports = [
"[project]/node_modules/.pnpm/react-ts-tab-lib@1.9.3_@heroui+system@2.4.23_@heroui+theme@2.4.23_tailwindcss@4.1.16__f_7f8b888a3643d80727c1db7cfb6decd5/node_modules/react-ts-tab-lib/dist/index-CotuWCE8.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Nr
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-ts-tab-lib@1.9.3_@heroui+system@2.4.23_@heroui+theme@2.4.23_tailwindcss@4.1.16__f_7f8b888a3643d80727c1db7cfb6decd5/node_modules/react-ts-tab-lib/dist/index-CuWp4vjI.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0_sass$40$1$2e$94$2e$2$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.0.1_@babel+core@7.28.5_react-dom@19.2.0_react@19.2.0__react@19.2.0_sass@1.94.2/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
;
;
function Xn(t, e) {
    t.indexOf(e) === -1 && t.push(e);
}
function Zn(t, e) {
    const n = t.indexOf(e);
    n > -1 && t.splice(n, 1);
}
const Jn = {
    useManualTiming: !1
};
// @__NO_SIDE_EFFECTS__
function ke(t) {
    let e;
    return ()=>(e === void 0 && (e = t()), e);
}
const Le = /* @__NO_SIDE_EFFECTS__ */ (t, e, n)=>{
    const s = e - t;
    return s === 0 ? 1 : (n - t) / s;
};
class Ot {
    constructor(){
        this.subscriptions = [];
    }
    add(e) {
        return Xn(this.subscriptions, e), ()=>Zn(this.subscriptions, e);
    }
    notify(e, n, s) {
        const i = this.subscriptions.length;
        if (i) if (i === 1) this.subscriptions[0](e, n, s);
        else for(let r = 0; r < i; r++){
            const o = this.subscriptions[r];
            o && o(e, n, s);
        }
    }
    getSize() {
        return this.subscriptions.length;
    }
    clear() {
        this.subscriptions.length = 0;
    }
}
const I = /* @__NO_SIDE_EFFECTS__ */ (t)=>t * 1e3, O = /* @__NO_SIDE_EFFECTS__ */ (t)=>t / 1e3;
function Kt(t, e) {
    return e ? t * (1e3 / e) : 0;
}
const Qn = /* @__PURE__ */ ke(()=>window.ScrollTimeline !== void 0);
class es {
    constructor(e){
        this.stop = ()=>this.runAll("stop"), this.animations = e.filter(Boolean);
    }
    get finished() {
        return Promise.all(this.animations.map((e)=>"finished" in e ? e.finished : e));
    }
    /**
   * TODO: Filter out cancelled or stopped animations before returning
   */ getAll(e) {
        return this.animations[0][e];
    }
    setAll(e, n) {
        for(let s = 0; s < this.animations.length; s++)this.animations[s][e] = n;
    }
    attachTimeline(e, n) {
        const s = this.animations.map((i)=>{
            if (Qn() && i.attachTimeline) return i.attachTimeline(e);
            if (typeof n == "function") return n(i);
        });
        return ()=>{
            s.forEach((i, r)=>{
                i && i(), this.animations[r].stop();
            });
        };
    }
    get time() {
        return this.getAll("time");
    }
    set time(e) {
        this.setAll("time", e);
    }
    get speed() {
        return this.getAll("speed");
    }
    set speed(e) {
        this.setAll("speed", e);
    }
    get startTime() {
        return this.getAll("startTime");
    }
    get duration() {
        let e = 0;
        for(let n = 0; n < this.animations.length; n++)e = Math.max(e, this.animations[n].duration);
        return e;
    }
    runAll(e) {
        this.animations.forEach((n)=>n[e]());
    }
    flatten() {
        this.runAll("flatten");
    }
    play() {
        this.runAll("play");
    }
    pause() {
        this.runAll("pause");
    }
    cancel() {
        this.runAll("cancel");
    }
    complete() {
        this.runAll("complete");
    }
}
class ts extends es {
    then(e, n) {
        return Promise.all(this.animations).then(e).catch(n);
    }
}
function Nt(t, e) {
    return t ? t[e] || t.default || t : void 0;
}
const Ve = 2e4;
function Bt(t) {
    let e = 0;
    const n = 50;
    let s = t.next(e);
    for(; !s.done && e < Ve;)e += n, s = t.next(e);
    return e >= Ve ? 1 / 0 : e;
}
function _e(t) {
    return typeof t == "function";
}
function Qe(t, e) {
    t.timeline = e, t.onfinish = null;
}
const Ge = (t)=>Array.isArray(t) && typeof t[0] == "number", ns = {
    linearEasing: void 0
};
function ss(t, e) {
    const n = /* @__PURE__ */ ke(t);
    return ()=>{
        var s;
        return (s = ns[e]) !== null && s !== void 0 ? s : n();
    };
}
const se = /* @__PURE__ */ ss(()=>{
    try {
        document.createElement("div").animate({
            opacity: 0
        }, {
            easing: "linear(0, 1)"
        });
    } catch  {
        return !1;
    }
    return !0;
}, "linearEasing"), kt = (t, e, n = 10)=>{
    let s = "";
    const i = Math.max(Math.round(e / n), 2);
    for(let r = 0; r < i; r++)s += t(/* @__PURE__ */ Le(0, i - 1, r)) + ", ";
    return `linear(${s.substring(0, s.length - 2)})`;
};
function Lt(t) {
    return !!(typeof t == "function" && se() || !t || typeof t == "string" && (t in Ae || se()) || Ge(t) || Array.isArray(t) && t.every(Lt));
}
const z = ([t, e, n, s])=>`cubic-bezier(${t}, ${e}, ${n}, ${s})`, Ae = {
    linear: "linear",
    ease: "ease",
    easeIn: "ease-in",
    easeOut: "ease-out",
    easeInOut: "ease-in-out",
    circIn: /* @__PURE__ */ z([
        0,
        0.65,
        0.55,
        1
    ]),
    circOut: /* @__PURE__ */ z([
        0.55,
        0,
        1,
        0.45
    ]),
    backIn: /* @__PURE__ */ z([
        0.31,
        0.01,
        0.66,
        -0.59
    ]),
    backOut: /* @__PURE__ */ z([
        0.33,
        1.53,
        0.69,
        0.99
    ])
};
function _t(t, e) {
    if (t) return typeof t == "function" && se() ? kt(t, e) : Ge(t) ? z(t) : Array.isArray(t) ? t.map((n)=>_t(n, e) || Ae.easeOut) : Ae[t];
}
let te;
function is() {
    te = void 0;
}
const K = {
    now: ()=>(te === void 0 && K.set(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["f"].isProcessing || Jn.useManualTiming ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["f"].timestamp : performance.now()), te),
    set: (t)=>{
        te = t, queueMicrotask(is);
    }
}, rs = {
    y: !1
};
function os() {
    return rs.y;
}
function as(t, e, n) {
    var s;
    if (t instanceof EventTarget) return [
        t
    ];
    if (typeof t == "string") {
        let i = document;
        const r = (s = void 0) !== null && s !== void 0 ? s : i.querySelectorAll(t);
        return r ? Array.from(r) : [];
    }
    return Array.from(t);
}
function Gt(t, e) {
    const n = as(t), s = new AbortController(), i = {
        passive: !0,
        ...e,
        signal: s.signal
    };
    return [
        n,
        i,
        ()=>s.abort()
    ];
}
function et(t) {
    return !(t.pointerType === "touch" || os());
}
function ls(t, e, n = {}) {
    const [s, i, r] = Gt(t, n), o = (a)=>{
        if (!et(a)) return;
        const { target: l } = a, u = e(l, a);
        if (typeof u != "function" || !l) return;
        const c = (h)=>{
            et(h) && (u(h), l.removeEventListener("pointerleave", c));
        };
        l.addEventListener("pointerleave", c, i);
    };
    return s.forEach((a)=>{
        a.addEventListener("pointerenter", o, i);
    }), r;
}
const Ut = (t, e)=>e ? t === e ? !0 : Ut(t, e.parentElement) : !1, us = (t)=>t.pointerType === "mouse" ? typeof t.button != "number" || t.button <= 0 : t.isPrimary !== !1, cs = /* @__PURE__ */ new Set([
    "BUTTON",
    "INPUT",
    "SELECT",
    "TEXTAREA",
    "A"
]);
function hs(t) {
    return cs.has(t.tagName) || t.tabIndex !== -1;
}
const H = /* @__PURE__ */ new WeakSet();
function tt(t) {
    return (e)=>{
        e.key === "Enter" && t(e);
    };
}
function pe(t, e) {
    t.dispatchEvent(new PointerEvent("pointer" + e, {
        isPrimary: !0,
        bubbles: !0
    }));
}
const ds = (t, e)=>{
    const n = t.currentTarget;
    if (!n) return;
    const s = tt(()=>{
        if (H.has(n)) return;
        pe(n, "down");
        const i = tt(()=>{
            pe(n, "up");
        }), r = ()=>pe(n, "cancel");
        n.addEventListener("keyup", i, e), n.addEventListener("blur", r, e);
    });
    n.addEventListener("keydown", s, e), n.addEventListener("blur", ()=>n.removeEventListener("keydown", s), e);
};
function nt(t) {
    return us(t) && !0;
}
function fs(t, e, n = {}) {
    const [s, i, r] = Gt(t, n), o = (a)=>{
        const l = a.currentTarget;
        if (!nt(a) || H.has(l)) return;
        H.add(l);
        const u = e(l, a), c = (f, b)=>{
            window.removeEventListener("pointerup", h), window.removeEventListener("pointercancel", d), !(!nt(f) || !H.has(l)) && (H.delete(l), typeof u == "function" && u(f, {
                success: b
            }));
        }, h = (f)=>{
            c(f, l === window || l === document || n.useGlobalTarget || Ut(l, f.target));
        }, d = (f)=>{
            c(f, !1);
        };
        window.addEventListener("pointerup", h, i), window.addEventListener("pointercancel", d, i);
    };
    return s.forEach((a)=>{
        (n.useGlobalTarget ? window : a).addEventListener("pointerdown", o, i), a instanceof HTMLElement && (a.addEventListener("focus", (u)=>ds(u, i)), !hs(a) && a.tabIndex === null && (a.tabIndex = 0));
    }), r;
}
const st = 30, ps = (t)=>!isNaN(parseFloat(t));
class ms {
    /**
   * @param init - The initiating value
   * @param config - Optional configuration options
   *
   * -  `transformer`: A function to transform incoming values with.
   */ constructor(e, n = {}){
        this.version = "12.6.1", this.canTrackVelocity = null, this.events = {}, this.updateAndNotify = (s, i = !0)=>{
            const r = K.now();
            this.updatedAt !== r && this.setPrevFrameValue(), this.prev = this.current, this.setCurrent(s), this.current !== this.prev && this.events.change && this.events.change.notify(this.current), i && this.events.renderRequest && this.events.renderRequest.notify(this.current);
        }, this.hasAnimated = !1, this.setCurrent(e), this.owner = n.owner;
    }
    setCurrent(e) {
        this.current = e, this.updatedAt = K.now(), this.canTrackVelocity === null && e !== void 0 && (this.canTrackVelocity = ps(this.current));
    }
    setPrevFrameValue(e = this.current) {
        this.prevFrameValue = e, this.prevUpdatedAt = this.updatedAt;
    }
    /**
   * Adds a function that will be notified when the `MotionValue` is updated.
   *
   * It returns a function that, when called, will cancel the subscription.
   *
   * When calling `onChange` inside a React component, it should be wrapped with the
   * `useEffect` hook. As it returns an unsubscribe function, this should be returned
   * from the `useEffect` function to ensure you don't add duplicate subscribers..
   *
   * ```jsx
   * export const MyComponent = () => {
   *   const x = useMotionValue(0)
   *   const y = useMotionValue(0)
   *   const opacity = useMotionValue(1)
   *
   *   useEffect(() => {
   *     function updateOpacity() {
   *       const maxXY = Math.max(x.get(), y.get())
   *       const newOpacity = transform(maxXY, [0, 100], [1, 0])
   *       opacity.set(newOpacity)
   *     }
   *
   *     const unsubscribeX = x.on("change", updateOpacity)
   *     const unsubscribeY = y.on("change", updateOpacity)
   *
   *     return () => {
   *       unsubscribeX()
   *       unsubscribeY()
   *     }
   *   }, [])
   *
   *   return <motion.div style={{ x }} />
   * }
   * ```
   *
   * @param subscriber - A function that receives the latest value.
   * @returns A function that, when called, will cancel this subscription.
   *
   * @deprecated
   */ onChange(e) {
        return ("TURBOPACK compile-time value", "development") !== "production" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["w"])(!1, 'value.onChange(callback) is deprecated. Switch to value.on("change", callback).'), this.on("change", e);
    }
    on(e, n) {
        this.events[e] || (this.events[e] = new Ot());
        const s = this.events[e].add(n);
        return e === "change" ? ()=>{
            s(), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a"].read(()=>{
                this.events.change.getSize() || this.stop();
            });
        } : s;
    }
    clearListeners() {
        for(const e in this.events)this.events[e].clear();
    }
    /**
   * Attaches a passive effect to the `MotionValue`.
   */ attach(e, n) {
        this.passiveEffect = e, this.stopPassiveEffect = n;
    }
    /**
   * Sets the state of the `MotionValue`.
   *
   * @remarks
   *
   * ```jsx
   * const x = useMotionValue(0)
   * x.set(10)
   * ```
   *
   * @param latest - Latest value to set.
   * @param render - Whether to notify render subscribers. Defaults to `true`
   *
   * @public
   */ set(e, n = !0) {
        !n || !this.passiveEffect ? this.updateAndNotify(e, n) : this.passiveEffect(e, this.updateAndNotify);
    }
    setWithVelocity(e, n, s) {
        this.set(n), this.prev = void 0, this.prevFrameValue = e, this.prevUpdatedAt = this.updatedAt - s;
    }
    /**
   * Set the state of the `MotionValue`, stopping any active animations,
   * effects, and resets velocity to `0`.
   */ jump(e, n = !0) {
        this.updateAndNotify(e), this.prev = e, this.prevUpdatedAt = this.prevFrameValue = void 0, n && this.stop(), this.stopPassiveEffect && this.stopPassiveEffect();
    }
    /**
   * Returns the latest state of `MotionValue`
   *
   * @returns - The latest state of `MotionValue`
   *
   * @public
   */ get() {
        return this.current;
    }
    /**
   * @public
   */ getPrevious() {
        return this.prev;
    }
    /**
   * Returns the latest velocity of `MotionValue`
   *
   * @returns - The latest velocity of `MotionValue`. Returns `0` if the state is non-numerical.
   *
   * @public
   */ getVelocity() {
        const e = K.now();
        if (!this.canTrackVelocity || this.prevFrameValue === void 0 || e - this.updatedAt > st) return 0;
        const n = Math.min(this.updatedAt - this.prevUpdatedAt, st);
        return Kt(parseFloat(this.current) - parseFloat(this.prevFrameValue), n);
    }
    /**
   * Registers a new animation to control this `MotionValue`. Only one
   * animation can drive a `MotionValue` at one time.
   *
   * ```jsx
   * value.start()
   * ```
   *
   * @param animation - A function that starts the provided animation
   */ start(e) {
        return this.stop(), new Promise((n)=>{
            this.hasAnimated = !0, this.animation = e(n), this.events.animationStart && this.events.animationStart.notify();
        }).then(()=>{
            this.events.animationComplete && this.events.animationComplete.notify(), this.clearAnimation();
        });
    }
    /**
   * Stop the currently active animation.
   *
   * @public
   */ stop() {
        this.animation && (this.animation.stop(), this.events.animationCancel && this.events.animationCancel.notify()), this.clearAnimation();
    }
    /**
   * Returns `true` if this value is currently animating.
   *
   * @public
   */ isAnimating() {
        return !!this.animation;
    }
    clearAnimation() {
        delete this.animation;
    }
    /**
   * Destroy and clean up subscribers to this `MotionValue`.
   *
   * The `MotionValue` hooks like `useMotionValue` and `useTransform` automatically
   * handle the lifecycle of the returned `MotionValue`, so this method is only necessary if you've manually
   * created a `MotionValue` via the `motionValue` function.
   *
   * @public
   */ destroy() {
        this.clearListeners(), this.stop(), this.stopPassiveEffect && this.stopPassiveEffect();
    }
}
function ie(t, e) {
    return new ms(t, e);
}
function J(t, e, n) {
    const s = t.getProps();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["r"])(s, e, n !== void 0 ? n : s.custom, t);
}
const $t = /* @__PURE__ */ new Set([
    "width",
    "height",
    "top",
    "left",
    "right",
    "bottom",
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["t"]
]);
function gs(t, e, n) {
    t.hasValue(e) ? t.getValue(e).set(n) : t.addValue(e, ie(n));
}
function ys(t, e) {
    const n = J(t, e);
    let { transitionEnd: s = {}, transition: i = {}, ...r } = n || {};
    r = {
        ...r,
        ...s
    };
    for(const o in r){
        const a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["b"])(r[o]);
        gs(t, o, a);
    }
}
function vs(t) {
    return !!((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["i"])(t) && t.add);
}
function bs(t, e) {
    const n = t.getValue("willChange");
    if (vs(n)) return n.add(e);
}
function Ts(t) {
    return t.props[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["o"]];
}
const jt = (t, e, n)=>(((1 - 3 * n + 3 * e) * t + (3 * n - 6 * e)) * t + 3 * e) * t, Vs = 1e-7, As = 12;
function Ss(t, e, n, s, i) {
    let r, o, a = 0;
    do o = e + (n - e) / 2, r = jt(o, s, i) - t, r > 0 ? n = o : e = o;
    while (Math.abs(r) > Vs && ++a < As)
    return o;
}
function ee(t, e, n, s) {
    if (t === e && n === s) return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["n"];
    const i = (r)=>Ss(r, 0, 1, t, n);
    return (r)=>r === 0 || r === 1 ? r : jt(i(r), e, s);
}
const qt = (t)=>(e)=>e <= 0.5 ? t(2 * e) / 2 : (2 - t(2 * (1 - e))) / 2, zt = (t)=>(e)=>1 - t(1 - e), Ht = /* @__PURE__ */ ee(0.33, 1.53, 0.69, 0.99), Ue = /* @__PURE__ */ zt(Ht), Wt = /* @__PURE__ */ qt(Ue), Yt = (t)=>(t *= 2) < 1 ? 0.5 * Ue(t) : 0.5 * (2 - Math.pow(2, -10 * (t - 1))), $e = (t)=>1 - Math.sin(Math.acos(t)), ws = zt($e), Xt = qt($e), Zt = (t)=>/^0[^.\s]+$/u.test(t);
function xs(t) {
    return typeof t == "number" ? t === 0 : t !== null ? t === "none" || t === "0" || Zt(t) : !0;
}
const W = (t)=>Math.round(t * 1e5) / 1e5, je = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu;
function Ms(t) {
    return t == null;
}
const Ps = /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu, qe = (t, e)=>(n)=>!!(typeof n == "string" && Ps.test(n) && n.startsWith(t) || e && !Ms(n) && Object.prototype.hasOwnProperty.call(n, e)), Jt = (t, e, n)=>(s)=>{
        if (typeof s != "string") return s;
        const [i, r, o, a] = s.match(je);
        return {
            [t]: parseFloat(i),
            [e]: parseFloat(r),
            [n]: parseFloat(o),
            alpha: a !== void 0 ? parseFloat(a) : 1
        };
    }, Cs = (t)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["e"])(0, 255, t), me = {
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["c"],
    transform: (t)=>Math.round(Cs(t))
}, B = {
    test: /* @__PURE__ */ qe("rgb", "red"),
    parse: /* @__PURE__ */ Jt("red", "green", "blue"),
    transform: ({ red: t, green: e, blue: n, alpha: s = 1 })=>"rgba(" + me.transform(t) + ", " + me.transform(e) + ", " + me.transform(n) + ", " + W(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["d"].transform(s)) + ")"
};
function Fs(t) {
    let e = "", n = "", s = "", i = "";
    return t.length > 5 ? (e = t.substring(1, 3), n = t.substring(3, 5), s = t.substring(5, 7), i = t.substring(7, 9)) : (e = t.substring(1, 2), n = t.substring(2, 3), s = t.substring(3, 4), i = t.substring(4, 5), e += e, n += n, s += s, i += i), {
        red: parseInt(e, 16),
        green: parseInt(n, 16),
        blue: parseInt(s, 16),
        alpha: i ? parseInt(i, 16) / 255 : 1
    };
}
const Se = {
    test: /* @__PURE__ */ qe("#"),
    parse: Fs,
    transform: B.transform
}, G = {
    test: /* @__PURE__ */ qe("hsl", "hue"),
    parse: /* @__PURE__ */ Jt("hue", "saturation", "lightness"),
    transform: ({ hue: t, saturation: e, lightness: n, alpha: s = 1 })=>"hsla(" + Math.round(t) + ", " + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["p"].transform(W(e)) + ", " + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["p"].transform(W(n)) + ", " + W(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["d"].transform(s)) + ")"
}, x = {
    test: (t)=>B.test(t) || Se.test(t) || G.test(t),
    parse: (t)=>B.test(t) ? B.parse(t) : G.test(t) ? G.parse(t) : Se.parse(t),
    transform: (t)=>typeof t == "string" ? t : t.hasOwnProperty("red") ? B.transform(t) : G.transform(t)
}, Ds = /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu;
function Es(t) {
    var e, n;
    return isNaN(t) && typeof t == "string" && (((e = t.match(je)) === null || e === void 0 ? void 0 : e.length) || 0) + (((n = t.match(Ds)) === null || n === void 0 ? void 0 : n.length) || 0) > 0;
}
const Qt = "number", en = "color", Is = "var", Rs = "var(", it = "${}", Os = /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;
function Q(t) {
    const e = t.toString(), n = [], s = {
        color: [],
        number: [],
        var: []
    }, i = [];
    let r = 0;
    const a = e.replace(Os, (l)=>(x.test(l) ? (s.color.push(r), i.push(en), n.push(x.parse(l))) : l.startsWith(Rs) ? (s.var.push(r), i.push(Is), n.push(l)) : (s.number.push(r), i.push(Qt), n.push(parseFloat(l))), ++r, it)).split(it);
    return {
        values: n,
        split: a,
        indexes: s,
        types: i
    };
}
function tn(t) {
    return Q(t).values;
}
function nn(t) {
    const { split: e, types: n } = Q(t), s = e.length;
    return (i)=>{
        let r = "";
        for(let o = 0; o < s; o++)if (r += e[o], i[o] !== void 0) {
            const a = n[o];
            a === Qt ? r += W(i[o]) : a === en ? r += x.transform(i[o]) : r += i[o];
        }
        return r;
    };
}
const Ks = (t)=>typeof t == "number" ? 0 : t;
function Ns(t) {
    const e = tn(t);
    return nn(t)(e.map(Ks));
}
const j = {
    test: Es,
    parse: tn,
    createTransformer: nn,
    getAnimatableNone: Ns
}, Bs = /* @__PURE__ */ new Set([
    "brightness",
    "contrast",
    "saturate",
    "opacity"
]);
function ks(t) {
    const [e, n] = t.slice(0, -1).split("(");
    if (e === "drop-shadow") return t;
    const [s] = n.match(je) || [];
    if (!s) return t;
    const i = n.replace(s, "");
    let r = Bs.has(e) ? 1 : 0;
    return s !== n && (r *= 100), e + "(" + r + i + ")";
}
const Ls = /\b([a-z-]*)\(.*?\)/gu, we = {
    ...j,
    getAnimatableNone: (t)=>{
        const e = t.match(Ls);
        return e ? e.map(ks).join(" ") : t;
    }
}, _s = {
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["g"],
    // Color props
    color: x,
    backgroundColor: x,
    outlineColor: x,
    fill: x,
    stroke: x,
    // Border props
    borderColor: x,
    borderTopColor: x,
    borderRightColor: x,
    borderBottomColor: x,
    borderLeftColor: x,
    filter: we,
    WebkitFilter: we
}, sn = (t)=>_s[t];
function rn(t, e) {
    let n = sn(t);
    return n !== we && (n = j), n.getAnimatableNone ? n.getAnimatableNone(e) : void 0;
}
const Gs = /* @__PURE__ */ new Set([
    "auto",
    "none",
    "0"
]);
function Us(t, e, n) {
    let s = 0, i;
    for(; s < t.length && !i;){
        const r = t[s];
        typeof r == "string" && !Gs.has(r) && Q(r).values.length && (i = t[s]), s++;
    }
    if (i && n) for (const r of e)t[r] = rn(n, i);
}
const k = (t)=>t * 180 / Math.PI, xe = (t)=>{
    const e = k(Math.atan2(t[1], t[0]));
    return Me(e);
}, $s = {
    x: 4,
    y: 5,
    translateX: 4,
    translateY: 5,
    scaleX: 0,
    scaleY: 3,
    scale: (t)=>(Math.abs(t[0]) + Math.abs(t[3])) / 2,
    rotate: xe,
    rotateZ: xe,
    skewX: (t)=>k(Math.atan(t[1])),
    skewY: (t)=>k(Math.atan(t[2])),
    skew: (t)=>(Math.abs(t[1]) + Math.abs(t[2])) / 2
}, Me = (t)=>(t = t % 360, t < 0 && (t += 360), t), rt = xe, ot = (t)=>Math.sqrt(t[0] * t[0] + t[1] * t[1]), at = (t)=>Math.sqrt(t[4] * t[4] + t[5] * t[5]), js = {
    x: 12,
    y: 13,
    z: 14,
    translateX: 12,
    translateY: 13,
    translateZ: 14,
    scaleX: ot,
    scaleY: at,
    scale: (t)=>(ot(t) + at(t)) / 2,
    rotateX: (t)=>Me(k(Math.atan2(t[6], t[5]))),
    rotateY: (t)=>Me(k(Math.atan2(-t[2], t[0]))),
    rotateZ: rt,
    rotate: rt,
    skewX: (t)=>k(Math.atan(t[4])),
    skewY: (t)=>k(Math.atan(t[1])),
    skew: (t)=>(Math.abs(t[1]) + Math.abs(t[4])) / 2
};
function lt(t) {
    return t.includes("scale") ? 1 : 0;
}
function Pe(t, e) {
    if (!t || t === "none") return lt(e);
    const n = t.match(/^matrix3d\(([-\d.e\s,]+)\)$/u);
    let s, i;
    if (n) s = js, i = n;
    else {
        const a = t.match(/^matrix\(([-\d.e\s,]+)\)$/u);
        s = $s, i = a;
    }
    if (!i) return lt(e);
    const r = s[e], o = i[1].split(",").map(zs);
    return typeof r == "function" ? r(o) : o[r];
}
const qs = (t, e)=>{
    const { transform: n = "none" } = getComputedStyle(t);
    return Pe(n, e);
};
function zs(t) {
    return parseFloat(t.trim());
}
const ut = (t)=>t === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["c"] || t === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["h"], Hs = /* @__PURE__ */ new Set([
    "x",
    "y",
    "z"
]), Ws = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["t"].filter((t)=>!Hs.has(t));
function Ys(t) {
    const e = [];
    return Ws.forEach((n)=>{
        const s = t.getValue(n);
        s !== void 0 && (e.push([
            n,
            s.get()
        ]), s.set(n.startsWith("scale") ? 1 : 0));
    }), e;
}
const $ = {
    // Dimensions
    width: ({ x: t }, { paddingLeft: e = "0", paddingRight: n = "0" })=>t.max - t.min - parseFloat(e) - parseFloat(n),
    height: ({ y: t }, { paddingTop: e = "0", paddingBottom: n = "0" })=>t.max - t.min - parseFloat(e) - parseFloat(n),
    top: (t, { top: e })=>parseFloat(e),
    left: (t, { left: e })=>parseFloat(e),
    bottom: ({ y: t }, { top: e })=>parseFloat(e) + (t.max - t.min),
    right: ({ x: t }, { left: e })=>parseFloat(e) + (t.max - t.min),
    // Transform
    x: (t, { transform: e })=>Pe(e, "x"),
    y: (t, { transform: e })=>Pe(e, "y")
};
$.translateX = $.x;
$.translateY = $.y;
const L = /* @__PURE__ */ new Set();
let Ce = !1, Fe = !1;
function on() {
    if (Fe) {
        const t = Array.from(L).filter((s)=>s.needsMeasurement), e = new Set(t.map((s)=>s.element)), n = /* @__PURE__ */ new Map();
        e.forEach((s)=>{
            const i = Ys(s);
            i.length && (n.set(s, i), s.render());
        }), t.forEach((s)=>s.measureInitialState()), e.forEach((s)=>{
            s.render();
            const i = n.get(s);
            i && i.forEach(([r, o])=>{
                var a;
                (a = s.getValue(r)) === null || a === void 0 || a.set(o);
            });
        }), t.forEach((s)=>s.measureEndState()), t.forEach((s)=>{
            s.suspendedScrollY !== void 0 && window.scrollTo(0, s.suspendedScrollY);
        });
    }
    Fe = !1, Ce = !1, L.forEach((t)=>t.complete()), L.clear();
}
function an() {
    L.forEach((t)=>{
        t.readKeyframes(), t.needsMeasurement && (Fe = !0);
    });
}
function Xs() {
    an(), on();
}
class ze {
    constructor(e, n, s, i, r, o = !1){
        this.isComplete = !1, this.isAsync = !1, this.needsMeasurement = !1, this.isScheduled = !1, this.unresolvedKeyframes = [
            ...e
        ], this.onComplete = n, this.name = s, this.motionValue = i, this.element = r, this.isAsync = o;
    }
    scheduleResolve() {
        this.isScheduled = !0, this.isAsync ? (L.add(this), Ce || (Ce = !0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a"].read(an), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a"].resolveKeyframes(on))) : (this.readKeyframes(), this.complete());
    }
    readKeyframes() {
        const { unresolvedKeyframes: e, name: n, element: s, motionValue: i } = this;
        for(let r = 0; r < e.length; r++)if (e[r] === null) if (r === 0) {
            const o = i == null ? void 0 : i.get(), a = e[e.length - 1];
            if (o !== void 0) e[0] = o;
            else if (s && n) {
                const l = s.readValue(n, a);
                l != null && (e[0] = l);
            }
            e[0] === void 0 && (e[0] = a), i && o === void 0 && i.set(e[0]);
        } else e[r] = e[r - 1];
    }
    setFinalKeyframe() {}
    measureInitialState() {}
    renderEndStyles() {}
    measureEndState() {}
    complete() {
        this.isComplete = !0, this.onComplete(this.unresolvedKeyframes, this.finalKeyframe), L.delete(this);
    }
    cancel() {
        this.isComplete || (this.isScheduled = !1, L.delete(this));
    }
    resume() {
        this.isComplete || this.scheduleResolve();
    }
}
const ln = (t)=>/^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(t), Zs = // eslint-disable-next-line redos-detector/no-unsafe-regex -- false positive, as it can match a lot of words
/^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;
function Js(t) {
    const e = Zs.exec(t);
    if (!e) return [
        , 
    ];
    const [, n, s, i] = e;
    return [
        `--${n ?? s}`,
        i
    ];
}
const Qs = 4;
function un(t, e, n = 1) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["k"])(n <= Qs, `Max CSS variable fallback depth detected in property "${t}". This may indicate a circular fallback dependency.`);
    const [s, i] = Js(t);
    if (!s) return;
    const r = window.getComputedStyle(e).getPropertyValue(s);
    if (r) {
        const o = r.trim();
        return ln(o) ? parseFloat(o) : o;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["j"])(i) ? un(i, e, n + 1) : i;
}
const cn = (t)=>(e)=>e.test(t), ei = {
    test: (t)=>t === "auto",
    parse: (t)=>t
}, hn = [
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["c"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["h"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["p"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["l"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["v"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["m"],
    ei
], ct = (t)=>hn.find(cn(t));
class dn extends ze {
    constructor(e, n, s, i, r){
        super(e, n, s, i, r, !0);
    }
    readKeyframes() {
        const { unresolvedKeyframes: e, element: n, name: s } = this;
        if (!n || !n.current) return;
        super.readKeyframes();
        for(let l = 0; l < e.length; l++){
            let u = e[l];
            if (typeof u == "string" && (u = u.trim(), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["j"])(u))) {
                const c = un(u, n.current);
                c !== void 0 && (e[l] = c), l === e.length - 1 && (this.finalKeyframe = u);
            }
        }
        if (this.resolveNoneKeyframes(), !$t.has(s) || e.length !== 2) return;
        const [i, r] = e, o = ct(i), a = ct(r);
        if (o !== a) if (ut(o) && ut(a)) for(let l = 0; l < e.length; l++){
            const u = e[l];
            typeof u == "string" && (e[l] = parseFloat(u));
        }
        else this.needsMeasurement = !0;
    }
    resolveNoneKeyframes() {
        const { unresolvedKeyframes: e, name: n } = this, s = [];
        for(let i = 0; i < e.length; i++)xs(e[i]) && s.push(i);
        s.length && Us(e, s, n);
    }
    measureInitialState() {
        const { element: e, unresolvedKeyframes: n, name: s } = this;
        if (!e || !e.current) return;
        s === "height" && (this.suspendedScrollY = window.pageYOffset), this.measuredOrigin = $[s](e.measureViewportBox(), window.getComputedStyle(e.current)), n[0] = this.measuredOrigin;
        const i = n[n.length - 1];
        i !== void 0 && e.getValue(s, i).jump(i, !1);
    }
    measureEndState() {
        var e;
        const { element: n, name: s, unresolvedKeyframes: i } = this;
        if (!n || !n.current) return;
        const r = n.getValue(s);
        r && r.jump(this.measuredOrigin, !1);
        const o = i.length - 1, a = i[o];
        i[o] = $[s](n.measureViewportBox(), window.getComputedStyle(n.current)), a !== null && this.finalKeyframe === void 0 && (this.finalKeyframe = a), !((e = this.removedTransforms) === null || e === void 0) && e.length && this.removedTransforms.forEach(([l, u])=>{
            n.getValue(l).set(u);
        }), this.resolveNoneKeyframes();
    }
}
const ht = (t, e)=>e === "zIndex" ? !1 : !!(typeof t == "number" || Array.isArray(t) || typeof t == "string" && // It's animatable if we have a string
    (j.test(t) || t === "0") && // And it contains numbers and/or colors
    !t.startsWith("url("));
function ti(t) {
    const e = t[0];
    if (t.length === 1) return !0;
    for(let n = 0; n < t.length; n++)if (t[n] !== e) return !0;
}
function ni(t, e, n, s) {
    const i = t[0];
    if (i === null) return !1;
    if (e === "display" || e === "visibility") return !0;
    const r = t[t.length - 1], o = ht(i, e), a = ht(r, e);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["q"])(o === a, `You are trying to animate ${e} from "${i}" to "${r}". ${i} is not an animatable value - to enable this animation set ${i} to a value animatable to ${r} via the \`style\` property.`), !o || !a ? !1 : ti(t) || (n === "spring" || _e(n)) && s;
}
const si = (t)=>t !== null;
function ue(t, { repeat: e, repeatType: n = "loop" }, s) {
    const i = t.filter(si), r = e && n !== "loop" && e % 2 === 1 ? 0 : i.length - 1;
    return !r || s === void 0 ? i[r] : s;
}
const ii = 40;
class fn {
    constructor({ autoplay: e = !0, delay: n = 0, type: s = "keyframes", repeat: i = 0, repeatDelay: r = 0, repeatType: o = "loop", ...a }){
        this.isStopped = !1, this.hasAttemptedResolve = !1, this.createdAt = K.now(), this.options = {
            autoplay: e,
            delay: n,
            type: s,
            repeat: i,
            repeatDelay: r,
            repeatType: o,
            ...a
        }, this.updateFinishedPromise();
    }
    /**
   * This method uses the createdAt and resolvedAt to calculate the
   * animation startTime. *Ideally*, we would use the createdAt time as t=0
   * as the following frame would then be the first frame of the animation in
   * progress, which would feel snappier.
   *
   * However, if there's a delay (main thread work) between the creation of
   * the animation and the first commited frame, we prefer to use resolvedAt
   * to avoid a sudden jump into the animation.
   */ calcStartTime() {
        return this.resolvedAt ? this.resolvedAt - this.createdAt > ii ? this.resolvedAt : this.createdAt : this.createdAt;
    }
    /**
   * A getter for resolved data. If keyframes are not yet resolved, accessing
   * this.resolved will synchronously flush all pending keyframe resolvers.
   * This is a deoptimisation, but at its worst still batches read/writes.
   */ get resolved() {
        return !this._resolved && !this.hasAttemptedResolve && Xs(), this._resolved;
    }
    /**
   * A method to be called when the keyframes resolver completes. This method
   * will check if its possible to run the animation and, if not, skip it.
   * Otherwise, it will call initPlayback on the implementing class.
   */ onKeyframesResolved(e, n) {
        this.resolvedAt = K.now(), this.hasAttemptedResolve = !0;
        const { name: s, type: i, velocity: r, delay: o, onComplete: a, onUpdate: l, isGenerator: u } = this.options;
        if (!u && !ni(e, s, i, r)) if (o) this.options.duration = 0;
        else {
            l && l(ue(e, this.options, n)), a && a(), this.resolveFinishedPromise();
            return;
        }
        const c = this.initPlayback(e, n);
        c !== !1 && (this._resolved = {
            keyframes: e,
            finalKeyframe: n,
            ...c
        }, this.onPostResolved());
    }
    onPostResolved() {}
    /**
   * Allows the returned animation to be awaited or promise-chained. Currently
   * resolves when the animation finishes at all but in a future update could/should
   * reject if its cancels.
   */ then(e, n) {
        return this.currentFinishedPromise.then(e, n);
    }
    flatten() {
        this.options.allowFlatten && (this.options.type = "keyframes", this.options.ease = "linear");
    }
    updateFinishedPromise() {
        this.currentFinishedPromise = new Promise((e)=>{
            this.resolveFinishedPromise = e;
        });
    }
}
const ce = (t, e, n)=>t + (e - t) * n;
function ge(t, e, n) {
    return n < 0 && (n += 1), n > 1 && (n -= 1), n < 1 / 6 ? t + (e - t) * 6 * n : n < 1 / 2 ? e : n < 2 / 3 ? t + (e - t) * (2 / 3 - n) * 6 : t;
}
function ri({ hue: t, saturation: e, lightness: n, alpha: s }) {
    t /= 360, e /= 100, n /= 100;
    let i = 0, r = 0, o = 0;
    if (!e) i = r = o = n;
    else {
        const a = n < 0.5 ? n * (1 + e) : n + e - n * e, l = 2 * n - a;
        i = ge(l, a, t + 1 / 3), r = ge(l, a, t), o = ge(l, a, t - 1 / 3);
    }
    return {
        red: Math.round(i * 255),
        green: Math.round(r * 255),
        blue: Math.round(o * 255),
        alpha: s
    };
}
function re(t, e) {
    return (n)=>n > 0 ? e : t;
}
const ye = (t, e, n)=>{
    const s = t * t, i = n * (e * e - s) + s;
    return i < 0 ? 0 : Math.sqrt(i);
}, oi = [
    Se,
    B,
    G
], ai = (t)=>oi.find((e)=>e.test(t));
function dt(t) {
    const e = ai(t);
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["q"])(!!e, `'${t}' is not an animatable color. Use the equivalent color code instead.`), !e) return !1;
    let n = e.parse(t);
    return e === G && (n = ri(n)), n;
}
const ft = (t, e)=>{
    const n = dt(t), s = dt(e);
    if (!n || !s) return re(t, e);
    const i = {
        ...n
    };
    return (r)=>(i.red = ye(n.red, s.red, r), i.green = ye(n.green, s.green, r), i.blue = ye(n.blue, s.blue, r), i.alpha = ce(n.alpha, s.alpha, r), B.transform(i));
}, li = (t, e)=>(n)=>e(t(n)), he = (...t)=>t.reduce(li), De = /* @__PURE__ */ new Set([
    "none",
    "hidden"
]);
function ui(t, e) {
    return De.has(t) ? (n)=>n <= 0 ? t : e : (n)=>n >= 1 ? e : t;
}
function ci(t, e) {
    return (n)=>ce(t, e, n);
}
function He(t) {
    return typeof t == "number" ? ci : typeof t == "string" ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["j"])(t) ? re : x.test(t) ? ft : fi : Array.isArray(t) ? pn : typeof t == "object" ? x.test(t) ? ft : hi : re;
}
function pn(t, e) {
    const n = [
        ...t
    ], s = n.length, i = t.map((r, o)=>He(r)(r, e[o]));
    return (r)=>{
        for(let o = 0; o < s; o++)n[o] = i[o](r);
        return n;
    };
}
function hi(t, e) {
    const n = {
        ...t,
        ...e
    }, s = {};
    for(const i in n)t[i] !== void 0 && e[i] !== void 0 && (s[i] = He(t[i])(t[i], e[i]));
    return (i)=>{
        for(const r in s)n[r] = s[r](i);
        return n;
    };
}
function di(t, e) {
    var n;
    const s = [], i = {
        color: 0,
        var: 0,
        number: 0
    };
    for(let r = 0; r < e.values.length; r++){
        const o = e.types[r], a = t.indexes[o][i[o]], l = (n = t.values[a]) !== null && n !== void 0 ? n : 0;
        s[r] = l, i[o]++;
    }
    return s;
}
const fi = (t, e)=>{
    const n = j.createTransformer(e), s = Q(t), i = Q(e);
    return s.indexes.var.length === i.indexes.var.length && s.indexes.color.length === i.indexes.color.length && s.indexes.number.length >= i.indexes.number.length ? De.has(t) && !i.values.length || De.has(e) && !s.values.length ? ui(t, e) : he(pn(di(s, i), i.values), n) : ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["q"])(!0, `Complex values '${t}' and '${e}' too different to mix. Ensure all colors are of the same type, and that each contains the same quantity of number and color values. Falling back to instant transition.`), re(t, e));
};
function mn(t, e, n) {
    return typeof t == "number" && typeof e == "number" && typeof n == "number" ? ce(t, e, n) : He(t)(t, e);
}
const pi = 5;
function gn(t, e, n) {
    const s = Math.max(e - pi, 0);
    return Kt(n - t(s), e - s);
}
const S = {
    // Default spring physics
    stiffness: 100,
    damping: 10,
    mass: 1,
    velocity: 0,
    // Default duration/bounce-based options
    duration: 800,
    // in ms
    bounce: 0.3,
    visualDuration: 0.3,
    // in seconds
    // Rest thresholds
    restSpeed: {
        granular: 0.01,
        default: 2
    },
    restDelta: {
        granular: 5e-3,
        default: 0.5
    },
    // Limits
    minDuration: 0.01,
    // in seconds
    maxDuration: 10,
    // in seconds
    minDamping: 0.05,
    maxDamping: 1
}, pt = 1e-3;
function mi({ duration: t = S.duration, bounce: e = S.bounce, velocity: n = S.velocity, mass: s = S.mass }) {
    let i, r;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["q"])(t <= /* @__PURE__ */ I(S.maxDuration), "Spring duration must be 10 seconds or less");
    let o = 1 - e;
    o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["e"])(S.minDamping, S.maxDamping, o), t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["e"])(S.minDuration, S.maxDuration, /* @__PURE__ */ O(t)), o < 1 ? (i = (u)=>{
        const c = u * o, h = c * t, d = c - n, f = Ee(u, o), b = Math.exp(-h);
        return pt - d / f * b;
    }, r = (u)=>{
        const h = u * o * t, d = h * n + n, f = Math.pow(o, 2) * Math.pow(u, 2) * t, b = Math.exp(-h), v = Ee(Math.pow(u, 2), o);
        return (-i(u) + pt > 0 ? -1 : 1) * ((d - f) * b) / v;
    }) : (i = (u)=>{
        const c = Math.exp(-u * t), h = (u - n) * t + 1;
        return -1e-3 + c * h;
    }, r = (u)=>{
        const c = Math.exp(-u * t), h = (n - u) * (t * t);
        return c * h;
    });
    const a = 5 / t, l = yi(i, r, a);
    if (t = /* @__PURE__ */ I(t), isNaN(l)) return {
        stiffness: S.stiffness,
        damping: S.damping,
        duration: t
    };
    {
        const u = Math.pow(l, 2) * s;
        return {
            stiffness: u,
            damping: o * 2 * Math.sqrt(s * u),
            duration: t
        };
    }
}
const gi = 12;
function yi(t, e, n) {
    let s = n;
    for(let i = 1; i < gi; i++)s = s - t(s) / e(s);
    return s;
}
function Ee(t, e) {
    return t * Math.sqrt(1 - e * e);
}
const vi = [
    "duration",
    "bounce"
], bi = [
    "stiffness",
    "damping",
    "mass"
];
function mt(t, e) {
    return e.some((n)=>t[n] !== void 0);
}
function Ti(t) {
    let e = {
        velocity: S.velocity,
        stiffness: S.stiffness,
        damping: S.damping,
        mass: S.mass,
        isResolvedFromDuration: !1,
        ...t
    };
    if (!mt(t, bi) && mt(t, vi)) if (t.visualDuration) {
        const n = t.visualDuration, s = 2 * Math.PI / (n * 1.2), i = s * s, r = 2 * (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["e"])(0.05, 1, 1 - (t.bounce || 0)) * Math.sqrt(i);
        e = {
            ...e,
            mass: S.mass,
            stiffness: i,
            damping: r
        };
    } else {
        const n = mi(t);
        e = {
            ...e,
            ...n,
            mass: S.mass
        }, e.isResolvedFromDuration = !0;
    }
    return e;
}
function yn(t = S.visualDuration, e = S.bounce) {
    const n = typeof t != "object" ? {
        visualDuration: t,
        keyframes: [
            0,
            1
        ],
        bounce: e
    } : t;
    let { restSpeed: s, restDelta: i } = n;
    const r = n.keyframes[0], o = n.keyframes[n.keyframes.length - 1], a = {
        done: !1,
        value: r
    }, { stiffness: l, damping: u, mass: c, duration: h, velocity: d, isResolvedFromDuration: f } = Ti({
        ...n,
        velocity: -/* @__PURE__ */ O(n.velocity || 0)
    }), b = d || 0, v = u / (2 * Math.sqrt(l * c)), y = o - r, p = /* @__PURE__ */ O(Math.sqrt(l / c)), T = Math.abs(y) < 5;
    s || (s = T ? S.restSpeed.granular : S.restSpeed.default), i || (i = T ? S.restDelta.granular : S.restDelta.default);
    let V;
    if (v < 1) {
        const g = Ee(p, v);
        V = (A)=>{
            const w = Math.exp(-v * p * A);
            return o - w * ((b + v * p * y) / g * Math.sin(g * A) + y * Math.cos(g * A));
        };
    } else if (v === 1) V = (g)=>o - Math.exp(-p * g) * (y + (b + p * y) * g);
    else {
        const g = p * Math.sqrt(v * v - 1);
        V = (A)=>{
            const w = Math.exp(-v * p * A), m = Math.min(g * A, 300);
            return o - w * ((b + v * p * y) * Math.sinh(m) + g * y * Math.cosh(m)) / g;
        };
    }
    const C = {
        calculatedDuration: f && h || null,
        next: (g)=>{
            const A = V(g);
            if (f) a.done = g >= h;
            else {
                let w = 0;
                v < 1 && (w = g === 0 ? /* @__PURE__ */ I(b) : gn(V, g, A));
                const m = Math.abs(w) <= s, P = Math.abs(o - A) <= i;
                a.done = m && P;
            }
            return a.value = a.done ? o : A, a;
        },
        toString: ()=>{
            const g = Math.min(Bt(C), Ve), A = kt((w)=>C.next(g * w).value, g, 30);
            return g + "ms " + A;
        }
    };
    return C;
}
function gt({ keyframes: t, velocity: e = 0, power: n = 0.8, timeConstant: s = 325, bounceDamping: i = 10, bounceStiffness: r = 500, modifyTarget: o, min: a, max: l, restDelta: u = 0.5, restSpeed: c }) {
    const h = t[0], d = {
        done: !1,
        value: h
    }, f = (m)=>a !== void 0 && m < a || l !== void 0 && m > l, b = (m)=>a === void 0 ? l : l === void 0 || Math.abs(a - m) < Math.abs(l - m) ? a : l;
    let v = n * e;
    const y = h + v, p = o === void 0 ? y : o(y);
    p !== y && (v = p - h);
    const T = (m)=>-v * Math.exp(-m / s), V = (m)=>p + T(m), C = (m)=>{
        const P = T(m), F = V(m);
        d.done = Math.abs(P) <= u, d.value = d.done ? p : F;
    };
    let g, A;
    const w = (m)=>{
        f(d.value) && (g = m, A = yn({
            keyframes: [
                d.value,
                b(d.value)
            ],
            velocity: gn(V, m, d.value),
            // TODO: This should be passing * 1000
            damping: i,
            stiffness: r,
            restDelta: u,
            restSpeed: c
        }));
    };
    return w(0), {
        calculatedDuration: null,
        next: (m)=>{
            let P = !1;
            return !A && g === void 0 && (P = !0, C(m), w(m)), g !== void 0 && m >= g ? A.next(m - g) : (!P && C(m), d);
        }
    };
}
const Vi = /* @__PURE__ */ ee(0.42, 0, 1, 1), Ai = /* @__PURE__ */ ee(0, 0, 0.58, 1), vn = /* @__PURE__ */ ee(0.42, 0, 0.58, 1), Si = (t)=>Array.isArray(t) && typeof t[0] != "number", yt = {
    linear: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["n"],
    easeIn: Vi,
    easeInOut: vn,
    easeOut: Ai,
    circIn: $e,
    circInOut: Xt,
    circOut: ws,
    backIn: Ue,
    backInOut: Wt,
    backOut: Ht,
    anticipate: Yt
}, vt = (t)=>{
    if (Ge(t)) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["k"])(t.length === 4, "Cubic bezier arrays must contain four numerical values.");
        const [e, n, s, i] = t;
        return ee(e, n, s, i);
    } else if (typeof t == "string") return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["k"])(yt[t] !== void 0, `Invalid easing type '${t}'`), yt[t];
    return t;
};
function wi(t, e, n) {
    const s = [], i = n || mn, r = t.length - 1;
    for(let o = 0; o < r; o++){
        let a = i(t[o], t[o + 1]);
        if (e) {
            const l = Array.isArray(e) ? e[o] || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["n"] : e;
            a = he(l, a);
        }
        s.push(a);
    }
    return s;
}
function xi(t, e, { clamp: n = !0, ease: s, mixer: i } = {}) {
    const r = t.length;
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["k"])(r === e.length, "Both input and output ranges must be the same length"), r === 1) return ()=>e[0];
    if (r === 2 && e[0] === e[1]) return ()=>e[1];
    const o = t[0] === t[1];
    t[0] > t[r - 1] && (t = [
        ...t
    ].reverse(), e = [
        ...e
    ].reverse());
    const a = wi(e, s, i), l = a.length, u = (c)=>{
        if (o && c < t[0]) return e[0];
        let h = 0;
        if (l > 1) for(; h < t.length - 2 && !(c < t[h + 1]); h++);
        const d = /* @__PURE__ */ Le(t[h], t[h + 1], c);
        return a[h](d);
    };
    return n ? (c)=>u((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["e"])(t[0], t[r - 1], c)) : u;
}
function Mi(t, e) {
    const n = t[t.length - 1];
    for(let s = 1; s <= e; s++){
        const i = /* @__PURE__ */ Le(0, e, s);
        t.push(ce(n, 1, i));
    }
}
function Pi(t) {
    const e = [
        0
    ];
    return Mi(e, t.length - 1), e;
}
function Ci(t, e) {
    return t.map((n)=>n * e);
}
function Fi(t, e) {
    return t.map(()=>e || vn).splice(0, t.length - 1);
}
function Y({ duration: t = 300, keyframes: e, times: n, ease: s = "easeInOut" }) {
    const i = Si(s) ? s.map(vt) : vt(s), r = {
        done: !1,
        value: e[0]
    }, o = Ci(// Only use the provided offsets if they're the correct length
    // TODO Maybe we should warn here if there's a length mismatch
    n && n.length === e.length ? n : Pi(e), t), a = xi(o, e, {
        ease: Array.isArray(i) ? i : Fi(e, i)
    });
    return {
        calculatedDuration: t,
        next: (l)=>(r.value = a(l), r.done = l >= t, r)
    };
}
const Di = (t)=>{
    const e = ({ timestamp: n })=>t(n);
    return {
        start: ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a"].update(e, !0),
        stop: ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["s"])(e),
        /**
     * If we're processing this frame we can use the
     * framelocked timestamp to keep things in sync.
     */ now: ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["f"].isProcessing ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["f"].timestamp : K.now()
    };
}, Ei = {
    decay: gt,
    inertia: gt,
    tween: Y,
    keyframes: Y,
    spring: yn
}, Ii = (t)=>t / 100;
class We extends fn {
    constructor(e){
        super(e), this.holdTime = null, this.cancelTime = null, this.currentTime = 0, this.playbackSpeed = 1, this.pendingPlayState = "running", this.startTime = null, this.state = "idle", this.stop = ()=>{
            if (this.resolver.cancel(), this.isStopped = !0, this.state === "idle") return;
            this.teardown();
            const { onStop: l } = this.options;
            l && l();
        };
        const { name: n, motionValue: s, element: i, keyframes: r } = this.options, o = (i == null ? void 0 : i.KeyframeResolver) || ze, a = (l, u)=>this.onKeyframesResolved(l, u);
        this.resolver = new o(r, a, n, s, i), this.resolver.scheduleResolve();
    }
    flatten() {
        super.flatten(), this._resolved && Object.assign(this._resolved, this.initPlayback(this._resolved.keyframes));
    }
    initPlayback(e) {
        const { type: n = "keyframes", repeat: s = 0, repeatDelay: i = 0, repeatType: r, velocity: o = 0 } = this.options, a = _e(n) ? n : Ei[n] || Y;
        let l, u;
        ("TURBOPACK compile-time value", "development") !== "production" && a !== Y && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["k"])(e.length <= 2, `Only two keyframes currently supported with spring and inertia animations. Trying to animate ${e}`), a !== Y && typeof e[0] != "number" && (l = he(Ii, mn(e[0], e[1])), e = [
            0,
            100
        ]);
        const c = a({
            ...this.options,
            keyframes: e
        });
        r === "mirror" && (u = a({
            ...this.options,
            keyframes: [
                ...e
            ].reverse(),
            velocity: -o
        })), c.calculatedDuration === null && (c.calculatedDuration = Bt(c));
        const { calculatedDuration: h } = c, d = h + i, f = d * (s + 1) - i;
        return {
            generator: c,
            mirroredGenerator: u,
            mapPercentToKeyframes: l,
            calculatedDuration: h,
            resolvedDuration: d,
            totalDuration: f
        };
    }
    onPostResolved() {
        const { autoplay: e = !0 } = this.options;
        this.play(), this.pendingPlayState === "paused" || !e ? this.pause() : this.state = this.pendingPlayState;
    }
    tick(e, n = !1) {
        const { resolved: s } = this;
        if (!s) {
            const { keyframes: m } = this.options;
            return {
                done: !0,
                value: m[m.length - 1]
            };
        }
        const { finalKeyframe: i, generator: r, mirroredGenerator: o, mapPercentToKeyframes: a, keyframes: l, calculatedDuration: u, totalDuration: c, resolvedDuration: h } = s;
        if (this.startTime === null) return r.next(0);
        const { delay: d, repeat: f, repeatType: b, repeatDelay: v, onUpdate: y } = this.options;
        this.speed > 0 ? this.startTime = Math.min(this.startTime, e) : this.speed < 0 && (this.startTime = Math.min(e - c / this.speed, this.startTime)), n ? this.currentTime = e : this.holdTime !== null ? this.currentTime = this.holdTime : this.currentTime = Math.round(e - this.startTime) * this.speed;
        const p = this.currentTime - d * (this.speed >= 0 ? 1 : -1), T = this.speed >= 0 ? p < 0 : p > c;
        this.currentTime = Math.max(p, 0), this.state === "finished" && this.holdTime === null && (this.currentTime = c);
        let V = this.currentTime, C = r;
        if (f) {
            const m = Math.min(this.currentTime, c) / h;
            let P = Math.floor(m), F = m % 1;
            !F && m >= 1 && (F = 1), F === 1 && P--, P = Math.min(P, f + 1), !!(P % 2) && (b === "reverse" ? (F = 1 - F, v && (F -= v / h)) : b === "mirror" && (C = o)), V = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["e"])(0, 1, F) * h;
        }
        const g = T ? {
            done: !1,
            value: l[0]
        } : C.next(V);
        a && (g.value = a(g.value));
        let { done: A } = g;
        !T && u !== null && (A = this.speed >= 0 ? this.currentTime >= c : this.currentTime <= 0);
        const w = this.holdTime === null && (this.state === "finished" || this.state === "running" && A);
        return w && i !== void 0 && (g.value = ue(l, this.options, i)), y && y(g.value), w && this.finish(), g;
    }
    get duration() {
        const { resolved: e } = this;
        return e ? /* @__PURE__ */ O(e.calculatedDuration) : 0;
    }
    get time() {
        return /* @__PURE__ */ O(this.currentTime);
    }
    set time(e) {
        e = /* @__PURE__ */ I(e), this.currentTime = e, this.holdTime !== null || this.speed === 0 ? this.holdTime = e : this.driver && (this.startTime = this.driver.now() - e / this.speed);
    }
    get speed() {
        return this.playbackSpeed;
    }
    set speed(e) {
        const n = this.playbackSpeed !== e;
        this.playbackSpeed = e, n && (this.time = /* @__PURE__ */ O(this.currentTime));
    }
    play() {
        if (this.resolver.isScheduled || this.resolver.resume(), !this._resolved) {
            this.pendingPlayState = "running";
            return;
        }
        if (this.isStopped) return;
        const { driver: e = Di, onPlay: n, startTime: s } = this.options;
        this.driver || (this.driver = e((r)=>this.tick(r))), n && n();
        const i = this.driver.now();
        this.holdTime !== null ? this.startTime = i - this.holdTime : this.startTime ? this.state === "finished" && (this.startTime = i) : this.startTime = s ?? this.calcStartTime(), this.state === "finished" && this.updateFinishedPromise(), this.cancelTime = this.startTime, this.holdTime = null, this.state = "running", this.driver.start();
    }
    pause() {
        var e;
        if (!this._resolved) {
            this.pendingPlayState = "paused";
            return;
        }
        this.state = "paused", this.holdTime = (e = this.currentTime) !== null && e !== void 0 ? e : 0;
    }
    complete() {
        this.state !== "running" && this.play(), this.pendingPlayState = this.state = "finished", this.holdTime = null;
    }
    finish() {
        this.teardown(), this.state = "finished";
        const { onComplete: e } = this.options;
        e && e();
    }
    cancel() {
        this.cancelTime !== null && this.tick(this.cancelTime), this.teardown(), this.updateFinishedPromise();
    }
    teardown() {
        this.state = "idle", this.stopDriver(), this.resolveFinishedPromise(), this.updateFinishedPromise(), this.startTime = this.cancelTime = null, this.resolver.cancel();
    }
    stopDriver() {
        this.driver && (this.driver.stop(), this.driver = void 0);
    }
    sample(e) {
        return this.startTime = 0, this.tick(e, !0);
    }
}
const Ri = /* @__PURE__ */ new Set([
    "opacity",
    "clipPath",
    "filter",
    "transform"
]);
function Oi(t, e, n, { delay: s = 0, duration: i = 300, repeat: r = 0, repeatType: o = "loop", ease: a = "easeInOut", times: l } = {}) {
    const u = {
        [e]: n
    };
    l && (u.offset = l);
    const c = _t(a, i);
    return Array.isArray(c) && (u.easing = c), t.animate(u, {
        delay: s,
        duration: i,
        easing: Array.isArray(c) ? "linear" : c,
        fill: "both",
        iterations: r + 1,
        direction: o === "reverse" ? "alternate" : "normal"
    });
}
const Ki = /* @__PURE__ */ ke(()=>Object.hasOwnProperty.call(Element.prototype, "animate")), oe = 10, Ni = 2e4;
function Bi(t) {
    return _e(t.type) || t.type === "spring" || !Lt(t.ease);
}
function ki(t, e) {
    const n = new We({
        ...e,
        keyframes: t,
        repeat: 0,
        delay: 0,
        isGenerator: !0
    });
    let s = {
        done: !1,
        value: t[0]
    };
    const i = [];
    let r = 0;
    for(; !s.done && r < Ni;)s = n.sample(r), i.push(s.value), r += oe;
    return {
        times: void 0,
        keyframes: i,
        duration: r - oe,
        ease: "linear"
    };
}
const bn = {
    anticipate: Yt,
    backInOut: Wt,
    circInOut: Xt
};
function Li(t) {
    return t in bn;
}
class bt extends fn {
    constructor(e){
        super(e);
        const { name: n, motionValue: s, element: i, keyframes: r } = this.options;
        this.resolver = new dn(r, (o, a)=>this.onKeyframesResolved(o, a), n, s, i), this.resolver.scheduleResolve();
    }
    initPlayback(e, n) {
        let { duration: s = 300, times: i, ease: r, type: o, motionValue: a, name: l, startTime: u } = this.options;
        if (!a.owner || !a.owner.current) return !1;
        if (typeof r == "string" && se() && Li(r) && (r = bn[r]), Bi(this.options)) {
            const { onComplete: h, onUpdate: d, motionValue: f, element: b, ...v } = this.options, y = ki(e, v);
            e = y.keyframes, e.length === 1 && (e[1] = e[0]), s = y.duration, i = y.times, r = y.ease, o = "keyframes";
        }
        const c = Oi(a.owner.current, l, e, {
            ...this.options,
            duration: s,
            times: i,
            ease: r
        });
        return c.startTime = u ?? this.calcStartTime(), this.pendingTimeline ? (Qe(c, this.pendingTimeline), this.pendingTimeline = void 0) : c.onfinish = ()=>{
            const { onComplete: h } = this.options;
            a.set(ue(e, this.options, n)), h && h(), this.cancel(), this.resolveFinishedPromise();
        }, {
            animation: c,
            duration: s,
            times: i,
            type: o,
            ease: r,
            keyframes: e
        };
    }
    get duration() {
        const { resolved: e } = this;
        if (!e) return 0;
        const { duration: n } = e;
        return /* @__PURE__ */ O(n);
    }
    get time() {
        const { resolved: e } = this;
        if (!e) return 0;
        const { animation: n } = e;
        return /* @__PURE__ */ O(n.currentTime || 0);
    }
    set time(e) {
        const { resolved: n } = this;
        if (!n) return;
        const { animation: s } = n;
        s.currentTime = /* @__PURE__ */ I(e);
    }
    get speed() {
        const { resolved: e } = this;
        if (!e) return 1;
        const { animation: n } = e;
        return n.playbackRate;
    }
    set speed(e) {
        const { resolved: n } = this;
        if (!n) return;
        const { animation: s } = n;
        s.playbackRate = e;
    }
    get state() {
        const { resolved: e } = this;
        if (!e) return "idle";
        const { animation: n } = e;
        return n.playState;
    }
    get startTime() {
        const { resolved: e } = this;
        if (!e) return null;
        const { animation: n } = e;
        return n.startTime;
    }
    /**
   * Replace the default DocumentTimeline with another AnimationTimeline.
   * Currently used for scroll animations.
   */ attachTimeline(e) {
        if (!this._resolved) this.pendingTimeline = e;
        else {
            const { resolved: n } = this;
            if (!n) return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["n"];
            const { animation: s } = n;
            Qe(s, e);
        }
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["n"];
    }
    play() {
        if (this.isStopped) return;
        const { resolved: e } = this;
        if (!e) return;
        const { animation: n } = e;
        n.playState === "finished" && this.updateFinishedPromise(), n.play();
    }
    pause() {
        const { resolved: e } = this;
        if (!e) return;
        const { animation: n } = e;
        n.pause();
    }
    stop() {
        if (this.resolver.cancel(), this.isStopped = !0, this.state === "idle") return;
        this.resolveFinishedPromise(), this.updateFinishedPromise();
        const { resolved: e } = this;
        if (!e) return;
        const { animation: n, keyframes: s, duration: i, type: r, ease: o, times: a } = e;
        if (n.playState === "idle" || n.playState === "finished") return;
        if (this.time) {
            const { motionValue: u, onUpdate: c, onComplete: h, element: d, ...f } = this.options, b = new We({
                ...f,
                keyframes: s,
                duration: i,
                type: r,
                ease: o,
                times: a,
                isGenerator: !0
            }), v = /* @__PURE__ */ I(this.time);
            u.setWithVelocity(b.sample(v - oe).value, b.sample(v).value, oe);
        }
        const { onStop: l } = this.options;
        l && l(), this.cancel();
    }
    complete() {
        const { resolved: e } = this;
        e && e.animation.finish();
    }
    cancel() {
        const { resolved: e } = this;
        e && e.animation.cancel();
    }
    static supports(e) {
        const { motionValue: n, name: s, repeatDelay: i, repeatType: r, damping: o, type: a } = e;
        if (!n || !n.owner || !(n.owner.current instanceof HTMLElement)) return !1;
        const { onUpdate: l, transformTemplate: u } = n.owner.getProps();
        return Ki() && s && Ri.has(s) && (s !== "transform" || !u) && /**
     * If we're outputting values to onUpdate then we can't use WAAPI as there's
     * no way to read the value from WAAPI every frame.
     */ !l && !i && r !== "mirror" && o !== 0 && a !== "inertia";
    }
}
const _i = {
    type: "spring",
    stiffness: 500,
    damping: 25,
    restSpeed: 10
}, Gi = (t)=>({
        type: "spring",
        stiffness: 550,
        damping: t === 0 ? 2 * Math.sqrt(550) : 30,
        restSpeed: 10
    }), Ui = {
    type: "keyframes",
    duration: 0.8
}, $i = {
    type: "keyframes",
    ease: [
        0.25,
        0.1,
        0.35,
        1
    ],
    duration: 0.3
}, ji = (t, { keyframes: e })=>e.length > 2 ? Ui : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["u"].has(t) ? t.startsWith("scale") ? Gi(e[1]) : _i : $i;
function qi({ when: t, delay: e, delayChildren: n, staggerChildren: s, staggerDirection: i, repeat: r, repeatType: o, repeatDelay: a, from: l, elapsed: u, ...c }) {
    return !!Object.keys(c).length;
}
const zi = (t, e, n, s = {}, i, r)=>(o)=>{
        const a = Nt(s, t) || {}, l = a.delay || s.delay || 0;
        let { elapsed: u = 0 } = s;
        u = u - /* @__PURE__ */ I(l);
        let c = {
            keyframes: Array.isArray(n) ? n : [
                null,
                n
            ],
            ease: "easeOut",
            velocity: e.getVelocity(),
            ...a,
            delay: -u,
            onUpdate: (d)=>{
                e.set(d), a.onUpdate && a.onUpdate(d);
            },
            onComplete: ()=>{
                o(), a.onComplete && a.onComplete();
            },
            name: t,
            motionValue: e,
            element: r ? void 0 : i
        };
        qi(a) || (c = {
            ...c,
            ...ji(t, c)
        }), c.duration && (c.duration = /* @__PURE__ */ I(c.duration)), c.repeatDelay && (c.repeatDelay = /* @__PURE__ */ I(c.repeatDelay)), c.from !== void 0 && (c.keyframes[0] = c.from);
        let h = !1;
        if ((c.type === !1 || c.duration === 0 && !c.repeatDelay) && (c.duration = 0, c.delay === 0 && (h = !0)), c.allowFlatten = !a.type && !a.ease, h && !r && e.get() !== void 0) {
            const d = ue(c.keyframes, a);
            if (d !== void 0) return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a"].update(()=>{
                c.onUpdate(d), c.onComplete();
            }), new ts([]);
        }
        return !r && bt.supports(c) ? new bt(c) : new We(c);
    };
function Hi({ protectedKeys: t, needsAnimating: e }, n) {
    const s = t.hasOwnProperty(n) && e[n] !== !0;
    return e[n] = !1, s;
}
function Tn(t, e, { delay: n = 0, transitionOverride: s, type: i } = {}) {
    var r;
    let { transition: o = t.getDefaultTransition(), transitionEnd: a, ...l } = e;
    s && (o = s);
    const u = [], c = i && t.animationState && t.animationState.getState()[i];
    for(const h in l){
        const d = t.getValue(h, (r = t.latestValues[h]) !== null && r !== void 0 ? r : null), f = l[h];
        if (f === void 0 || c && Hi(c, h)) continue;
        const b = {
            delay: n,
            ...Nt(o || {}, h)
        };
        let v = !1;
        if (window.MotionHandoffAnimation) {
            const p = Ts(t);
            if (p) {
                const T = window.MotionHandoffAnimation(p, h, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a"]);
                T !== null && (b.startTime = T, v = !0);
            }
        }
        bs(t, h), d.start(zi(h, d, f, t.shouldReduceMotion && $t.has(h) ? {
            type: !1
        } : b, t, v));
        const y = d.animation;
        y && u.push(y);
    }
    return a && Promise.all(u).then(()=>{
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a"].update(()=>{
            a && ys(t, a);
        });
    }), u;
}
function Ie(t, e, n = {}) {
    var s;
    const i = J(t, e, n.type === "exit" ? (s = t.presenceContext) === null || s === void 0 ? void 0 : s.custom : void 0);
    let { transition: r = t.getDefaultTransition() || {} } = i || {};
    n.transitionOverride && (r = n.transitionOverride);
    const o = i ? ()=>Promise.all(Tn(t, i, n)) : ()=>Promise.resolve(), a = t.variantChildren && t.variantChildren.size ? (u = 0)=>{
        const { delayChildren: c = 0, staggerChildren: h, staggerDirection: d } = r;
        return Wi(t, e, c + u, h, d, n);
    } : ()=>Promise.resolve(), { when: l } = r;
    if (l) {
        const [u, c] = l === "beforeChildren" ? [
            o,
            a
        ] : [
            a,
            o
        ];
        return u().then(()=>c());
    } else return Promise.all([
        o(),
        a(n.delay)
    ]);
}
function Wi(t, e, n = 0, s = 0, i = 1, r) {
    const o = [], a = (t.variantChildren.size - 1) * s, l = i === 1 ? (u = 0)=>u * s : (u = 0)=>a - u * s;
    return Array.from(t.variantChildren).sort(Yi).forEach((u, c)=>{
        u.notify("AnimationStart", e), o.push(Ie(u, e, {
            ...r,
            delay: n + l(c)
        }).then(()=>u.notify("AnimationComplete", e)));
    }), Promise.all(o);
}
function Yi(t, e) {
    return t.sortNodePosition(e);
}
function Xi(t, e, n = {}) {
    t.notify("AnimationStart", e);
    let s;
    if (Array.isArray(e)) {
        const i = e.map((r)=>Ie(t, r, n));
        s = Promise.all(i);
    } else if (typeof e == "string") s = Ie(t, e, n);
    else {
        const i = typeof e == "function" ? J(t, e, n.custom) : e;
        s = Promise.all(Tn(t, i, n));
    }
    return s.then(()=>{
        t.notify("AnimationComplete", e);
    });
}
function Vn(t, e) {
    if (!Array.isArray(e)) return !1;
    const n = e.length;
    if (n !== t.length) return !1;
    for(let s = 0; s < n; s++)if (e[s] !== t[s]) return !1;
    return !0;
}
const Zi = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["y"].length;
function An(t) {
    if (!t) return;
    if (!t.isControllingVariants) {
        const n = t.parent ? An(t.parent) || {} : {};
        return t.props.initial !== void 0 && (n.initial = t.props.initial), n;
    }
    const e = {};
    for(let n = 0; n < Zi; n++){
        const s = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["y"][n], i = t.props[s];
        ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["x"])(i) || i === !1) && (e[s] = i);
    }
    return e;
}
const Ji = [
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["B"]
].reverse(), Qi = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["B"].length;
function er(t) {
    return (e)=>Promise.all(e.map(({ animation: n, options: s })=>Xi(t, n, s)));
}
function tr(t) {
    let e = er(t), n = Tt(), s = !0;
    const i = (l)=>(u, c)=>{
            var h;
            const d = J(t, c, l === "exit" ? (h = t.presenceContext) === null || h === void 0 ? void 0 : h.custom : void 0);
            if (d) {
                const { transition: f, transitionEnd: b, ...v } = d;
                u = {
                    ...u,
                    ...v,
                    ...b
                };
            }
            return u;
        };
    function r(l) {
        e = l(t);
    }
    function o(l) {
        const { props: u } = t, c = An(t.parent) || {}, h = [], d = /* @__PURE__ */ new Set();
        let f = {}, b = 1 / 0;
        for(let y = 0; y < Qi; y++){
            const p = Ji[y], T = n[p], V = u[p] !== void 0 ? u[p] : c[p], C = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["x"])(V), g = p === l ? T.isActive : null;
            g === !1 && (b = y);
            let A = V === c[p] && V !== u[p] && C;
            if (A && s && t.manuallyAnimateOnMount && (A = !1), T.protectedKeys = {
                ...f
            }, !T.isActive && g === null || // If we didn't and don't have any defined prop for this animation type
            !V && !T.prevProp || // Or if the prop doesn't define an animation
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"])(V) || typeof V == "boolean") continue;
            const w = nr(T.prevProp, V);
            let m = w || // If we're making this variant active, we want to always make it active
            p === l && T.isActive && !A && C || // If we removed a higher-priority variant (i is in reverse order)
            y > b && C, P = !1;
            const F = Array.isArray(V) ? V : [
                V
            ];
            let _ = F.reduce(i(p), {});
            g === !1 && (_ = {});
            const { prevResolvedValues: Ye = {} } = T, Pn = {
                ...Ye,
                ..._
            }, Xe = (M)=>{
                m = !0, d.has(M) && (P = !0, d.delete(M)), T.needsAnimating[M] = !0;
                const E = t.getValue(M);
                E && (E.liveStyle = !1);
            };
            for(const M in Pn){
                const E = _[M], de = Ye[M];
                if (f.hasOwnProperty(M)) continue;
                let fe = !1;
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["A"])(E) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["A"])(de) ? fe = !Vn(E, de) : fe = E !== de, fe ? E != null ? Xe(M) : d.add(M) : E !== void 0 && d.has(M) ? Xe(M) : T.protectedKeys[M] = !0;
            }
            T.prevProp = V, T.prevResolvedValues = _, T.isActive && (f = {
                ...f,
                ..._
            }), s && t.blockInitialAnimation && (m = !1), m && (!(A && w) || P) && h.push(...F.map((M)=>({
                    animation: M,
                    options: {
                        type: p
                    }
                })));
        }
        if (d.size) {
            const y = {};
            if (typeof u.initial != "boolean") {
                const p = J(t, Array.isArray(u.initial) ? u.initial[0] : u.initial);
                p && p.transition && (y.transition = p.transition);
            }
            d.forEach((p)=>{
                const T = t.getBaseTarget(p), V = t.getValue(p);
                V && (V.liveStyle = !0), y[p] = T ?? null;
            }), h.push({
                animation: y
            });
        }
        let v = !!h.length;
        return s && (u.initial === !1 || u.initial === u.animate) && !t.manuallyAnimateOnMount && (v = !1), s = !1, v ? e(h) : Promise.resolve();
    }
    function a(l, u) {
        var c;
        if (n[l].isActive === u) return Promise.resolve();
        (c = t.variantChildren) === null || c === void 0 || c.forEach((d)=>{
            var f;
            return (f = d.animationState) === null || f === void 0 ? void 0 : f.setActive(l, u);
        }), n[l].isActive = u;
        const h = o(l);
        for(const d in n)n[d].protectedKeys = {};
        return h;
    }
    return {
        animateChanges: o,
        setActive: a,
        setAnimateFunction: r,
        getState: ()=>n,
        reset: ()=>{
            n = Tt(), s = !0;
        }
    };
}
function nr(t, e) {
    return typeof e == "string" ? e !== t : Array.isArray(e) ? !Vn(e, t) : !1;
}
function N(t = !1) {
    return {
        isActive: t,
        protectedKeys: {},
        needsAnimating: {},
        prevResolvedValues: {}
    };
}
function Tt() {
    return {
        animate: N(!0),
        whileInView: N(),
        whileHover: N(),
        whileTap: N(),
        whileDrag: N(),
        whileFocus: N(),
        exit: N()
    };
}
class q {
    constructor(e){
        this.isMounted = !1, this.node = e;
    }
    update() {}
}
class sr extends q {
    /**
   * We dynamically generate the AnimationState manager as it contains a reference
   * to the underlying animation library. We only want to load that if we load this,
   * so people can optionally code split it out using the `m` component.
   */ constructor(e){
        super(e), e.animationState || (e.animationState = tr(e));
    }
    updateAnimationControlsSubscription() {
        const { animate: e } = this.node.getProps();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["z"])(e) && (this.unmountControls = e.subscribe(this.node));
    }
    /**
   * Subscribe any provided AnimationControls to the component's VisualElement
   */ mount() {
        this.updateAnimationControlsSubscription();
    }
    update() {
        const { animate: e } = this.node.getProps(), { animate: n } = this.node.prevProps || {};
        e !== n && this.updateAnimationControlsSubscription();
    }
    unmount() {
        var e;
        this.node.animationState.reset(), (e = this.unmountControls) === null || e === void 0 || e.call(this);
    }
}
let ir = 0;
class rr extends q {
    constructor(){
        super(...arguments), this.id = ir++;
    }
    update() {
        if (!this.node.presenceContext) return;
        const { isPresent: e, onExitComplete: n } = this.node.presenceContext, { isPresent: s } = this.node.prevPresenceContext || {};
        if (!this.node.animationState || e === s) return;
        const i = this.node.animationState.setActive("exit", !e);
        n && !e && i.then(()=>{
            n(this.id);
        });
    }
    mount() {
        const { register: e, onExitComplete: n } = this.node.presenceContext || {};
        n && n(this.id), e && (this.unmount = e(this.id));
    }
    unmount() {}
}
const or = {
    animation: {
        Feature: sr
    },
    exit: {
        Feature: rr
    }
};
function Vt(t, e, n, s = {
    passive: !0
}) {
    return t.addEventListener(e, n, s), ()=>t.removeEventListener(e, n);
}
function Sn(t) {
    return {
        point: {
            x: t.pageX,
            y: t.pageY
        }
    };
}
function ar({ top: t, left: e, right: n, bottom: s }) {
    return {
        x: {
            min: e,
            max: n
        },
        y: {
            min: t,
            max: s
        }
    };
}
function lr(t, e) {
    if (!e) return t;
    const n = e({
        x: t.left,
        y: t.top
    }), s = e({
        x: t.right,
        y: t.bottom
    });
    return {
        top: n.y,
        left: n.x,
        bottom: s.y,
        right: s.x
    };
}
const At = ()=>({
        min: 0,
        max: 0
    }), wn = ()=>({
        x: At(),
        y: At()
    });
function ur(t, e) {
    return ar(lr(t.getBoundingClientRect(), e));
}
function St(t, e, n) {
    const { props: s } = t;
    t.animationState && s.whileHover && t.animationState.setActive("whileHover", n === "Start");
    const i = "onHover" + n, r = s[i];
    r && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a"].postRender(()=>r(e, Sn(e)));
}
class cr extends q {
    mount() {
        const { current: e } = this.node;
        e && (this.unmount = ls(e, (n, s)=>(St(this.node, s, "Start"), (i)=>St(this.node, i, "End"))));
    }
    unmount() {}
}
class hr extends q {
    constructor(){
        super(...arguments), this.isActive = !1;
    }
    onFocus() {
        let e = !1;
        try {
            e = this.node.current.matches(":focus-visible");
        } catch  {
            e = !0;
        }
        !e || !this.node.animationState || (this.node.animationState.setActive("whileFocus", !0), this.isActive = !0);
    }
    onBlur() {
        !this.isActive || !this.node.animationState || (this.node.animationState.setActive("whileFocus", !1), this.isActive = !1);
    }
    mount() {
        this.unmount = he(Vt(this.node.current, "focus", ()=>this.onFocus()), Vt(this.node.current, "blur", ()=>this.onBlur()));
    }
    unmount() {}
}
function wt(t, e, n) {
    const { props: s } = t;
    if (t.current instanceof HTMLButtonElement && t.current.disabled) return;
    t.animationState && s.whileTap && t.animationState.setActive("whileTap", n === "Start");
    const i = "onTap" + (n === "End" ? "" : n), r = s[i];
    r && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a"].postRender(()=>r(e, Sn(e)));
}
class dr extends q {
    mount() {
        const { current: e } = this.node;
        e && (this.unmount = fs(e, (n, s)=>(wt(this.node, s, "Start"), (i, { success: r })=>wt(this.node, i, r ? "End" : "Cancel")), {
            useGlobalTarget: this.node.props.globalTapTarget
        }));
    }
    unmount() {}
}
const Re = /* @__PURE__ */ new WeakMap(), ve = /* @__PURE__ */ new WeakMap(), fr = (t)=>{
    const e = Re.get(t.target);
    e && e(t);
}, pr = (t)=>{
    t.forEach(fr);
};
function mr({ root: t, ...e }) {
    const n = t || document;
    ve.has(n) || ve.set(n, {});
    const s = ve.get(n), i = JSON.stringify(e);
    return s[i] || (s[i] = new IntersectionObserver(pr, {
        root: t,
        ...e
    })), s[i];
}
function gr(t, e, n) {
    const s = mr(e);
    return Re.set(t, n), s.observe(t), ()=>{
        Re.delete(t), s.unobserve(t);
    };
}
const yr = {
    some: 0,
    all: 1
};
class vr extends q {
    constructor(){
        super(...arguments), this.hasEnteredView = !1, this.isInView = !1;
    }
    startObserver() {
        this.unmount();
        const { viewport: e = {} } = this.node.getProps(), { root: n, margin: s, amount: i = "some", once: r } = e, o = {
            root: n ? n.current : void 0,
            rootMargin: s,
            threshold: typeof i == "number" ? i : yr[i]
        }, a = (l)=>{
            const { isIntersecting: u } = l;
            if (this.isInView === u || (this.isInView = u, r && !u && this.hasEnteredView)) return;
            u && (this.hasEnteredView = !0), this.node.animationState && this.node.animationState.setActive("whileInView", u);
            const { onViewportEnter: c, onViewportLeave: h } = this.node.getProps(), d = u ? c : h;
            d && d(l);
        };
        return gr(this.node.current, o, a);
    }
    mount() {
        this.startObserver();
    }
    update() {
        if (typeof IntersectionObserver > "u") return;
        const { props: e, prevProps: n } = this.node;
        [
            "amount",
            "margin",
            "root"
        ].some(br(e, n)) && this.startObserver();
    }
    unmount() {}
}
function br({ viewport: t = {} }, { viewport: e = {} } = {}) {
    return (n)=>t[n] !== e[n];
}
const Tr = {
    inView: {
        Feature: vr
    },
    tap: {
        Feature: dr
    },
    focus: {
        Feature: hr
    },
    hover: {
        Feature: cr
    }
}, Oe = {
    current: null
}, xn = {
    current: !1
};
function Vr() {
    if (xn.current = !0, !!__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["C"]) if (window.matchMedia) {
        const t = window.matchMedia("(prefers-reduced-motion)"), e = ()=>Oe.current = t.matches;
        t.addListener(e), e();
    } else Oe.current = !1;
}
const Ar = [
    ...hn,
    x,
    j
], Sr = (t)=>Ar.find(cn(t)), wr = /* @__PURE__ */ new WeakMap();
function xr(t, e, n) {
    for(const s in e){
        const i = e[s], r = n[s];
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["i"])(i)) t.addValue(s, i), ("TURBOPACK compile-time value", "development") === "development" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["w"])(i.version === "12.6.2", `Attempting to mix Motion versions ${i.version} with 12.6.2 may not work as expected.`);
        else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["i"])(r)) t.addValue(s, ie(i, {
            owner: t
        }));
        else if (r !== i) if (t.hasValue(s)) {
            const o = t.getValue(s);
            o.liveStyle === !0 ? o.jump(i) : o.hasAnimated || o.set(i);
        } else {
            const o = t.getStaticValue(s);
            t.addValue(s, ie(o !== void 0 ? o : i, {
                owner: t
            }));
        }
    }
    for(const s in n)e[s] === void 0 && t.removeValue(s);
    return e;
}
const xt = [
    "AnimationStart",
    "AnimationComplete",
    "Update",
    "BeforeLayoutMeasure",
    "LayoutMeasure",
    "LayoutAnimationStart",
    "LayoutAnimationComplete"
];
class Mr {
    /**
   * This method takes React props and returns found MotionValues. For example, HTML
   * MotionValues will be found within the style prop, whereas for Three.js within attribute arrays.
   *
   * This isn't an abstract method as it needs calling in the constructor, but it is
   * intended to be one.
   */ scrapeMotionValuesFromProps(e, n, s) {
        return {};
    }
    constructor({ parent: e, props: n, presenceContext: s, reducedMotionConfig: i, blockInitialAnimation: r, visualState: o }, a = {}){
        this.current = null, this.children = /* @__PURE__ */ new Set(), this.isVariantNode = !1, this.isControllingVariants = !1, this.shouldReduceMotion = null, this.values = /* @__PURE__ */ new Map(), this.KeyframeResolver = ze, this.features = {}, this.valueSubscriptions = /* @__PURE__ */ new Map(), this.prevMotionValues = {}, this.events = {}, this.propEventSubscriptions = {}, this.notifyUpdate = ()=>this.notify("Update", this.latestValues), this.render = ()=>{
            this.current && (this.triggerBuild(), this.renderInstance(this.current, this.renderState, this.props.style, this.projection));
        }, this.renderScheduledAt = 0, this.scheduleRender = ()=>{
            const f = K.now();
            this.renderScheduledAt < f && (this.renderScheduledAt = f, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a"].render(this.render, !1, !0));
        };
        const { latestValues: l, renderState: u, onUpdate: c } = o;
        this.onUpdate = c, this.latestValues = l, this.baseTarget = {
            ...l
        }, this.initialValues = n.initial ? {
            ...l
        } : {}, this.renderState = u, this.parent = e, this.props = n, this.presenceContext = s, this.depth = e ? e.depth + 1 : 0, this.reducedMotionConfig = i, this.options = a, this.blockInitialAnimation = !!r, this.isControllingVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["D"])(n), this.isVariantNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["E"])(n), this.isVariantNode && (this.variantChildren = /* @__PURE__ */ new Set()), this.manuallyAnimateOnMount = !!(e && e.current);
        const { willChange: h, ...d } = this.scrapeMotionValuesFromProps(n, {}, this);
        for(const f in d){
            const b = d[f];
            l[f] !== void 0 && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["i"])(b) && b.set(l[f], !1);
        }
    }
    mount(e) {
        this.current = e, wr.set(e, this), this.projection && !this.projection.instance && this.projection.mount(e), this.parent && this.isVariantNode && !this.isControllingVariants && (this.removeFromVariantTree = this.parent.addVariantChild(this)), this.values.forEach((n, s)=>this.bindToMotionValue(s, n)), xn.current || Vr(), this.shouldReduceMotion = this.reducedMotionConfig === "never" ? !1 : this.reducedMotionConfig === "always" ? !0 : Oe.current, ("TURBOPACK compile-time value", "development") !== "production" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["w"])(this.shouldReduceMotion !== !0, "You have Reduced Motion enabled on your device. Animations may not appear as expected."), this.parent && this.parent.children.add(this), this.update(this.props, this.presenceContext);
    }
    unmount() {
        this.projection && this.projection.unmount(), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["s"])(this.notifyUpdate), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["s"])(this.render), this.valueSubscriptions.forEach((e)=>e()), this.valueSubscriptions.clear(), this.removeFromVariantTree && this.removeFromVariantTree(), this.parent && this.parent.children.delete(this);
        for(const e in this.events)this.events[e].clear();
        for(const e in this.features){
            const n = this.features[e];
            n && (n.unmount(), n.isMounted = !1);
        }
        this.current = null;
    }
    bindToMotionValue(e, n) {
        this.valueSubscriptions.has(e) && this.valueSubscriptions.get(e)();
        const s = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["u"].has(e);
        s && this.onBindTransform && this.onBindTransform();
        const i = n.on("change", (a)=>{
            this.latestValues[e] = a, this.props.onUpdate && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a"].preRender(this.notifyUpdate), s && this.projection && (this.projection.isTransformDirty = !0);
        }), r = n.on("renderRequest", this.scheduleRender);
        let o;
        window.MotionCheckAppearSync && (o = window.MotionCheckAppearSync(this, e, n)), this.valueSubscriptions.set(e, ()=>{
            i(), r(), o && o(), n.owner && n.stop();
        });
    }
    sortNodePosition(e) {
        return !this.current || !this.sortInstanceNodePosition || this.type !== e.type ? 0 : this.sortInstanceNodePosition(this.current, e.current);
    }
    updateFeatures() {
        let e = "animation";
        for(e in __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["F"]){
            const n = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["F"][e];
            if (!n) continue;
            const { isEnabled: s, Feature: i } = n;
            if (!this.features[e] && i && s(this.props) && (this.features[e] = new i(this)), this.features[e]) {
                const r = this.features[e];
                r.isMounted ? r.update() : (r.mount(), r.isMounted = !0);
            }
        }
    }
    triggerBuild() {
        this.build(this.renderState, this.latestValues, this.props);
    }
    /**
   * Measure the current viewport box with or without transforms.
   * Only measures axis-aligned boxes, rotate and skew must be manually
   * removed with a re-render to work.
   */ measureViewportBox() {
        return this.current ? this.measureInstanceViewportBox(this.current, this.props) : wn();
    }
    getStaticValue(e) {
        return this.latestValues[e];
    }
    setStaticValue(e, n) {
        this.latestValues[e] = n;
    }
    /**
   * Update the provided props. Ensure any newly-added motion values are
   * added to our map, old ones removed, and listeners updated.
   */ update(e, n) {
        (e.transformTemplate || this.props.transformTemplate) && this.scheduleRender(), this.prevProps = this.props, this.props = e, this.prevPresenceContext = this.presenceContext, this.presenceContext = n;
        for(let s = 0; s < xt.length; s++){
            const i = xt[s];
            this.propEventSubscriptions[i] && (this.propEventSubscriptions[i](), delete this.propEventSubscriptions[i]);
            const r = "on" + i, o = e[r];
            o && (this.propEventSubscriptions[i] = this.on(i, o));
        }
        this.prevMotionValues = xr(this, this.scrapeMotionValuesFromProps(e, this.prevProps, this), this.prevMotionValues), this.handleChildMotionValue && this.handleChildMotionValue(), this.onUpdate && this.onUpdate(this);
    }
    getProps() {
        return this.props;
    }
    /**
   * Returns the variant definition with a given name.
   */ getVariant(e) {
        return this.props.variants ? this.props.variants[e] : void 0;
    }
    /**
   * Returns the defined default transition on this component.
   */ getDefaultTransition() {
        return this.props.transition;
    }
    getTransformPagePoint() {
        return this.props.transformPagePoint;
    }
    getClosestVariantNode() {
        return this.isVariantNode ? this : this.parent ? this.parent.getClosestVariantNode() : void 0;
    }
    /**
   * Add a child visual element to our set of children.
   */ addVariantChild(e) {
        const n = this.getClosestVariantNode();
        if (n) return n.variantChildren && n.variantChildren.add(e), ()=>n.variantChildren.delete(e);
    }
    /**
   * Add a motion value and bind it to this visual element.
   */ addValue(e, n) {
        const s = this.values.get(e);
        n !== s && (s && this.removeValue(e), this.bindToMotionValue(e, n), this.values.set(e, n), this.latestValues[e] = n.get());
    }
    /**
   * Remove a motion value and unbind any active subscriptions.
   */ removeValue(e) {
        this.values.delete(e);
        const n = this.valueSubscriptions.get(e);
        n && (n(), this.valueSubscriptions.delete(e)), delete this.latestValues[e], this.removeValueFromRenderState(e, this.renderState);
    }
    /**
   * Check whether we have a motion value for this key
   */ hasValue(e) {
        return this.values.has(e);
    }
    getValue(e, n) {
        if (this.props.values && this.props.values[e]) return this.props.values[e];
        let s = this.values.get(e);
        return s === void 0 && n !== void 0 && (s = ie(n === null ? void 0 : n, {
            owner: this
        }), this.addValue(e, s)), s;
    }
    /**
   * If we're trying to animate to a previously unencountered value,
   * we need to check for it in our state and as a last resort read it
   * directly from the instance (which might have performance implications).
   */ readValue(e, n) {
        var s;
        let i = this.latestValues[e] !== void 0 || !this.current ? this.latestValues[e] : (s = this.getBaseTargetFromProps(this.props, e)) !== null && s !== void 0 ? s : this.readValueFromInstance(this.current, e, this.options);
        return i != null && (typeof i == "string" && (ln(i) || Zt(i)) ? i = parseFloat(i) : !Sr(i) && j.test(n) && (i = rn(e, n)), this.setBaseTarget(e, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["i"])(i) ? i.get() : i)), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["i"])(i) ? i.get() : i;
    }
    /**
   * Set the base target to later animate back to. This is currently
   * only hydrated on creation and when we first read a value.
   */ setBaseTarget(e, n) {
        this.baseTarget[e] = n;
    }
    /**
   * Find the base target for a value thats been removed from all animation
   * props.
   */ getBaseTarget(e) {
        var n;
        const { initial: s } = this.props;
        let i;
        if (typeof s == "string" || typeof s == "object") {
            const o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["r"])(this.props, s, (n = this.presenceContext) === null || n === void 0 ? void 0 : n.custom);
            o && (i = o[e]);
        }
        if (s && i !== void 0) return i;
        const r = this.getBaseTargetFromProps(this.props, e);
        return r !== void 0 && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["i"])(r) ? r : this.initialValues[e] !== void 0 && i === void 0 ? void 0 : this.baseTarget[e];
    }
    on(e, n) {
        return this.events[e] || (this.events[e] = new Ot()), this.events[e].add(n);
    }
    notify(e, ...n) {
        this.events[e] && this.events[e].notify(...n);
    }
}
class Mn extends Mr {
    constructor(){
        super(...arguments), this.KeyframeResolver = dn;
    }
    sortInstanceNodePosition(e, n) {
        return e.compareDocumentPosition(n) & 2 ? 1 : -1;
    }
    getBaseTargetFromProps(e, n) {
        return e.style ? e.style[n] : void 0;
    }
    removeValueFromRenderState(e, { vars: n, style: s }) {
        delete n[e], delete s[e];
    }
    handleChildMotionValue() {
        this.childSubscription && (this.childSubscription(), delete this.childSubscription);
        const { children: e } = this.props;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["i"])(e) && (this.childSubscription = e.on("change", (n)=>{
            this.current && (this.current.textContent = `${n}`);
        }));
    }
}
function Pr(t) {
    return window.getComputedStyle(t);
}
class Cr extends Mn {
    constructor(){
        super(...arguments), this.type = "html", this.renderInstance = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["G"];
    }
    readValueFromInstance(e, n) {
        if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["u"].has(n)) return qs(e, n);
        {
            const s = Pr(e), i = ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["H"])(n) ? s.getPropertyValue(n) : s[n]) || 0;
            return typeof i == "string" ? i.trim() : i;
        }
    }
    measureInstanceViewportBox(e, { transformPagePoint: n }) {
        return ur(e, n);
    }
    build(e, n, s) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["I"])(e, n, s.transformTemplate);
    }
    scrapeMotionValuesFromProps(e, n, s) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["J"])(e, n, s);
    }
}
class Fr extends Mn {
    constructor(){
        super(...arguments), this.type = "svg", this.isSVGTag = !1, this.measureInstanceViewportBox = wn, this.updateDimensions = ()=>{
            this.current && !this.renderState.dimensions && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["K"])(this.current, this.renderState);
        };
    }
    getBaseTargetFromProps(e, n) {
        return e[n];
    }
    readValueFromInstance(e, n) {
        if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["u"].has(n)) {
            const s = sn(n);
            return s && s.default || 0;
        }
        return n = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["M"].has(n) ? n : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["L"])(n), e.getAttribute(n);
    }
    scrapeMotionValuesFromProps(e, n, s) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["N"])(e, n, s);
    }
    onBindTransform() {
        this.current && !this.renderState.dimensions && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["a"].postRender(this.updateDimensions);
    }
    build(e, n, s) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["O"])(e, n, this.isSVGTag, s.transformTemplate);
    }
    renderInstance(e, n, s, i) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["P"])(e, n, s, i);
    }
    mount(e) {
        this.isSVGTag = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Q"])(e.tagName), super.mount(e);
    }
}
const Dr = (t, e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$ts$2d$tab$2d$lib$40$1$2e$9$2e$3_$40$heroui$2b$system$40$2$2e$4$2e$23_$40$heroui$2b$theme$40$2$2e$4$2e$23_tailwindcss$40$4$2e$1$2e$16_$5f$f_7f8b888a3643d80727c1db7cfb6decd5$2f$node_modules$2f$react$2d$ts$2d$tab$2d$lib$2f$dist$2f$index$2d$CuWp4vjI$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["R"])(t) ? new Fr(e) : new Cr(e, {
        allowProjection: t !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0_sass$40$1$2e$94$2e$2$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"]
    }), Er = {
    renderer: Dr,
    ...or,
    ...Tr
};
var Nr = Er;
;
}),
];

//# sourceMappingURL=0d5ff_react-ts-tab-lib_dist_index-CotuWCE8_f28f9549.js.map