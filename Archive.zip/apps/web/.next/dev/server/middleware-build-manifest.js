globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/ec2e8_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_7d4a86da._.js",
    "static/chunks/ec2e8_next_dist_compiled_react-dom_7619be84._.js",
    "static/chunks/ec2e8_next_dist_compiled_react-server-dom-turbopack_848bcc94._.js",
    "static/chunks/ec2e8_next_dist_compiled_next-devtools_index_11607193.js",
    "static/chunks/ec2e8_next_dist_compiled_c70b9247._.js",
    "static/chunks/ec2e8_next_dist_client_d7d2fed1._.js",
    "static/chunks/ec2e8_next_dist_2bee7c97._.js",
    "static/chunks/69652_@swc_helpers_cjs_679851cc._.js",
    "static/chunks/apps_web_a0ff3932._.js",
    "static/chunks/turbopack-apps_web_c59fa4f7._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];